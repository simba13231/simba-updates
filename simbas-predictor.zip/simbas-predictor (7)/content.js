// content.js — runs in ISOLATED world (extension context)
// Receives postMessage from interceptor.js and forwards to background via chrome.runtime

const seenIds = new Set();

function extractArray(data) {
  if (Array.isArray(data)) return data;
  for (const key of ["data","flips","results","items","coinflips","records","history","games"]) {
    if (Array.isArray(data[key])) return data[key];
  }
  for (const key of Object.keys(data || {})) {
    if (Array.isArray(data[key]) && data[key].length > 0) return data[key];
  }
  return null;
}

function getResult(item) {
  // Bloxyspin uses "winnercoin" with value "heads" or "trails" (typo for tails)
  const raw = (
    item.winnercoin ?? item.winnerCoin ??
    item.winner ?? item.result ?? item.outcome ?? item.side ??
    item.Winner ?? item.Result ?? item.Outcome ?? item.Side ??
    item.winnerSide ?? item.flip_result ?? item.flipResult ??
    item.winning_side ?? item.winningSide ?? ""
  ).toString().toLowerCase().trim();

  if (raw === "heads" || raw === "head" || raw === "h" || raw === "0") return "heads";
  // "trails" is Bloxyspin's typo for "tails"
  if (raw === "tails" || raw === "trails" || raw === "tail" || raw === "t" || raw === "1") return "tails";
  const n = Number(raw);
  if (!isNaN(n) && raw !== "") return n % 2 === 0 ? "heads" : "tails";
  return null;
}

function getId(item) {
  // Bloxyspin uses "_id" as the primary key
  return item._id ?? item.id ?? item.flipId ?? item.gameId ?? item.uuid ?? item.roomId ?? null;
}

function getTimestamp(item) {
  if (item.createdAt)  return new Date(item.createdAt).getTime();
  if (item.created_at) return new Date(item.created_at).getTime();
  if (item.timestamp)  return Number(item.timestamp);
  if (item.time)       return Number(item.time);
  return Date.now();
}

function tryParseFlips(payload, sourceType) {
  if (!payload || typeof payload !== "object") return;

  const candidates = [];

  const arr = extractArray(payload);
  if (arr) arr.forEach(i => candidates.push(i));
  if (getResult(payload)) candidates.push(payload);

  // Socket.IO event: ["eventName", {...}]
  if (Array.isArray(payload) && payload.length >= 2 && typeof payload[1] === "object") {
    const inner = extractArray(payload[1]);
    if (inner) inner.forEach(i => candidates.push(i));
    if (getResult(payload[1])) candidates.push(payload[1]);
  }

  for (const item of candidates) {
    const result = getResult(item);
    if (!result) continue;

    const id = getId(item);
    const key = id ? String(id) : JSON.stringify(item).slice(0, 80);
    if (seenIds.has(key)) continue;
    seenIds.add(key);
    if (seenIds.size > 1000) seenIds.delete(seenIds.values().next().value);

    chrome.runtime.sendMessage({
      type: "ADD_FLIP",
      result,
      id: id ? String(id) : null,
      timestamp: getTimestamp(item),
      source: sourceType
    }).catch(() => {});

    showToast(result);
  }
}

function extractMineData(obj) {
  if (!obj || typeof obj !== "object") return null;
  const mineData = {};
  const keys = Object.keys(obj);
  for (const key of keys) {
    const lower = key.toLowerCase();
    const isBattleIdKey = lower === "id" || lower === "_id" || lower === "uuid" || lower === "battleid" || lower === "gameid" || lower === "roomid" || lower === "matchid" || lower === "sessionid";
    if (
      isBattleIdKey ||
      lower.includes("bomb") || lower.includes("mine") || lower.includes("grid") || lower.includes("cell") || lower.includes("pvp") ||
      lower.includes("battle") || lower.includes("game") || lower.includes("room") || lower.includes("match") || lower.includes("session")
    ) {
      mineData[key] = obj[key];
    }
  }
  if (!Object.keys(mineData).length) return null;
  return mineData;
}

function tryParseMines(payload, sourceType) {
  if (!payload || typeof payload !== "object") return;

  const candidates = [];
  const arr = extractArray(payload);
  if (arr) arr.forEach(i => candidates.push(i));
  candidates.push(payload);

  if (Array.isArray(payload) && payload.length >= 2 && typeof payload[1] === "object") {
    const inner = extractArray(payload[1]);
    if (inner) inner.forEach(i => candidates.push(i));
    candidates.push(payload[1]);
  }

  for (const item of candidates) {
    // Only capture completed games (active: false means game ended)
    if (item.active !== false) continue;
    
    const mine = extractMineData(item);
    if (!mine) continue;
    
    // Try to extract bomb positions from board if game is completed
    const bombs = extractBombPositionsFromBoard(item);
    
    const key = JSON.stringify(mine).slice(0, 120);
    if (seenIds.has(key)) continue;
    seenIds.add(key);
    if (seenIds.size > 1000) seenIds.delete(seenIds.values().next().value);

    chrome.runtime.sendMessage({
      type: "ADD_MINE_DATA",
      data: {
        mine,
        bombs: bombs || [],
        bombCount: item.bombCount || bombs?.length || 0,
        source: sourceType,
        timestamp: Date.now()
      }
    }).catch(() => {});
  }
}

function extractBombPositionsFromBoard(gameItem) {
  if (!gameItem || !gameItem.board || !Array.isArray(gameItem.board)) return [];
  
  const bombs = [];
  gameItem.board.forEach((cell, idx) => {
    // Check if cell indicates a bomb was here
    if (cell && (cell.bomb === true || cell.mine === true || cell.isBomb === true || cell.hasBomb === true || cell.revealed === true && cell.type === "bomb")) {
      const row = Math.floor(idx / 5);
      const col = idx % 5;
      bombs.push(`${row},${col}`);
    }
  });
  
  return bombs;
}

// Listen for messages from interceptor.js
window.addEventListener("message", (e) => {
  if (!e.data || !e.data.__xprd) return;
  tryParseFlips(e.data.payload, e.data.type);
  tryParseMines(e.data.payload, e.data.type);
});

// ── Auto Join ─────────────────────────────────────────
function isVisibleElement(el) {
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== "hidden" && window.getComputedStyle(el).display !== "none";
}

function clickAutoJoinElement(el) {
  if (!el) return;
  const eventOptions = { bubbles: true, cancelable: true, view: window };
  if (typeof el.focus === "function") el.focus();
  if (typeof el.scrollIntoView === "function") {
    try { el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (e) {}
  }
  el.dispatchEvent(new MouseEvent("mouseenter", eventOptions));
  el.dispatchEvent(new MouseEvent("mouseover", eventOptions));
  el.dispatchEvent(new MouseEvent("mousedown", eventOptions));
  el.dispatchEvent(new MouseEvent("mouseup", eventOptions));
  el.dispatchEvent(new MouseEvent("click", eventOptions));
  if (typeof el.click === "function") {
    try { el.click(); } catch (e) {}
  }
}

function pickWager(minJoin, maxJoin) {
  const lo = Math.max(1, Math.round(minJoin));
  const hi = Math.max(lo, Math.round(maxJoin));
  return lo === hi ? lo : Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

// ── Get the side the JOINER would be on in a given card ──────────────────────
// The card has two side-badge images: <img alt="heads"> or <img alt="trails">
// The first badge (left avatar) is the CREATOR's side.
// Clicking Join puts you on the OPPOSITE side from the creator.
function getCardJoinerSide(card) {
  const badges = Array.from(card.querySelectorAll('img[alt="heads"], img[alt="trails"]'));
  if (!badges.length) return null;
  // First badge = creator's side
  const creatorAlt = badges[0].getAttribute("alt").toLowerCase().trim();
  // "trails" is Bloxyspin's typo for tails
  const creatorSide = (creatorAlt === "heads") ? "heads" : "tails";
  return creatorSide === "heads" ? "tails" : "heads";
}

// ── Find the flip card that is level 3 above a Join button ──────────────────
function getFlipCard(joinBtn) {
  let node = joinBtn;
  for (let i = 0; i < 3; i++) {
    if (!node.parentElement) return null;
    node = node.parentElement;
  }
  return node;
}

function tryAutoJoin(side, minJoin, maxJoin) {
  // "tails" is stored as "trails" in Bloxyspin's alt text — normalise on our end
  const wantSide = side; // "heads" or "tails"

  // Find every visible Join button on the page
  const joinBtns = Array.from(document.querySelectorAll("button")).filter(btn => {
    const text = (btn.textContent || "").trim().toLowerCase();
    return text === "join" && !btn.disabled && isVisibleElement(btn);
  });

  if (!joinBtns.length) {
    showToast("🤖 AUTO JOIN FAILED: No Join buttons found", "error");
    return { success: false, reason: "No Join buttons found on page" };
  }

  // Find a card whose joiner-side matches what we want
  let target = null;
  for (const btn of joinBtns) {
    const card = getFlipCard(btn);
    if (!card) continue;
    const joinerSide = getCardJoinerSide(card);
    if (joinerSide === wantSide) {
      target = btn;
      break;
    }
  }

  // If no side-matched card found, log what we saw and fail cleanly
  if (!target) {
    const sides = joinBtns.map(btn => {
      const card = getFlipCard(btn);
      return card ? (getCardJoinerSide(card) || "unknown") : "no-card";
    });
    showToast(`🤖 AUTO JOIN FAILED: No ${wantSide} flip available (found: ${sides.join(", ")})`, "warn");
    return { success: false, reason: `No ${wantSide} flip available. Available sides: ${sides.join(", ")}` };
  }

  clickAutoJoinElement(target);
  showToast(`🤖 AUTO JOINED: ${wantSide.toUpperCase()}`, "success");
  return { success: true, detail: `Joined ${wantSide} flip` };
}

// ── Toast ──────────────────────────────────────────────
function showToast(message, type = "auto") {
  const existing = document.getElementById("bloxy-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "bloxy-toast";

  const background = type === "success"
    ? "#6ee7b7"
    : type === "error"
    ? "#fca5a5"
    : type === "warn"
    ? "#fbbf24"
    : "#a855f7";

  toast.style.cssText = `
    position:fixed;bottom:24px;right:24px;
    background:${background};
    color:#0f172a;font-family:'Courier New',monospace;font-weight:700;
    font-size:13px;padding:10px 18px;border-radius:6px;z-index:999999;
    box-shadow:0 4px 20px rgba(0,0,0,0.4);transition:opacity 0.4s;
    letter-spacing:0.05em;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => { toast.style.opacity = "0"; }, 2000);
  setTimeout(() => toast.remove(), 2600);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "MANUAL_FLIP") showToast(message.result);

  if (message.type === "AUTO_JOIN") {
    const result = tryAutoJoin(message.side, message.minJoin, message.maxJoin);
    sendResponse(result);
    return true;
  }

  if (message.type === "AUTO_JOIN_GIVEAWAY") {
    const result = tryAutoJoinGiveaway();
    sendResponse(result);
    return true;
  }
});

function getClickableAncestor(el) {
  if (!el || !el.closest) return null;
  return el.closest('button, a, [role="button"], [onclick]') || el;
}

function hasGiveawayContext(el) {
  const keywords = /(giveaway|pvp|mine|bomb|prize|reward|ticket|spin to win|enter now|join now|win big|jackpot)/i;
  let node = el;
  let depth = 0;
  while (node && node !== document.body && depth < 6) {
    const text = (node.textContent || "").toLowerCase();
    const cls = (node.className || "").toString().toLowerCase();
    if (keywords.test(text) || keywords.test(cls)) return true;
    node = node.parentElement;
    depth++;
  }
  return false;
}

function tryAutoJoinGiveaway() {
  const giveawayMatches = ["giveaway", "enter giveaway", "join giveaway", "free", "prize", "claim", "join", "enter"];
  const allEls = Array.from(
    document.querySelectorAll('button, [role="button"], a, div[onclick], span, [class*="giveaway"], [class*="prize"], [class*="claim"], [class*="join"]')
  );

  for (const el of allEls) {
    const text = (el.textContent || el.innerText || el.getAttribute("aria-label") || "").toLowerCase().trim();
    const classes = (el.className || "").toLowerCase();
    const dataAction = (el.getAttribute("data-action") || el.getAttribute("data-type") || "").toLowerCase();

    if (text.length > 200) continue;
    if (!giveawayMatches.some(m => text.includes(m) || classes.includes(m) || dataAction.includes(m))) continue;
    if (!hasGiveawayContext(el)) continue;

    const target = getClickableAncestor(el);
    if (!target) continue;
    const rect = target.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    if (target.disabled) continue;

    target.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
    target.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
    target.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    target.click();
    target.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));

    showToast("🎁 GIVEAWAY JOINED");
    return { success: true, detail: `${target.tagName.toLowerCase()} · text: ${text.slice(0, 20)}` };
  }

  return { success: false, reason: "No giveaway button found on page" };
}

// ── Giveaway Auto Join Continuous Monitor ─────────────
let autoJoinGiveawayEnabled = false;
let clickedGiveawayElements = new WeakSet();

function loadAutoJoinGiveawaySetting() {
  chrome.storage.local.get(["xpSettings"], (r) => {
    if (r.xpSettings && r.xpSettings.autoJoinGiveaway !== undefined) {
      autoJoinGiveawayEnabled = r.xpSettings.autoJoinGiveaway;
    }
  });
}

function monitorGiveaways() {
  if (!autoJoinGiveawayEnabled) return;

  const giveawayMatches = ["giveaway", "enter giveaway", "join giveaway", "free", "prize", "claim", "spin to win", "enter now", "join now", "join"];
  const allEls = Array.from(
    document.querySelectorAll('button, [role="button"], a, div[onclick], span, [class*="giveaway"], [class*="prize"], [class*="claim"], [class*="free"], [class*="join"]')
  );

  for (const el of allEls) {
    const target = getClickableAncestor(el);
    if (!target) continue;
    if (clickedGiveawayElements.has(target)) continue;

    const text = (el.textContent || el.innerText || el.getAttribute("aria-label") || "").toLowerCase().trim();
    const classes = (el.className || "").toLowerCase();
    const dataAction = (el.getAttribute("data-action") || el.getAttribute("data-type") || "").toLowerCase();

    if (text.length > 200) continue;
    if (!giveawayMatches.some(m => text.includes(m) || classes.includes(m) || dataAction.includes(m))) continue;
    if (!hasGiveawayContext(el)) continue;

    const rect = target.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    if (target.disabled) continue;

    clickedGiveawayElements.add(target);
    target.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
    target.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
    target.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    target.click();
    target.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));

    showToast("🎁 GIVEAWAY AUTO JOINED");
  }
}

// Start monitoring giveaways every 300ms
loadAutoJoinGiveawaySetting();
const giveawayMonitorInterval = setInterval(monitorGiveaways, 300);

// Listen for storage changes to update settings
chrome.storage.onChanged.addListener((changes) => {
  if (changes.xpSettings) {
    const newSettings = changes.xpSettings.newValue;
    if (newSettings && newSettings.autoJoinGiveaway !== undefined) {
      autoJoinGiveawayEnabled = newSettings.autoJoinGiveaway;
    }
  }
});

// ══════════════════════════════════════════════════════
//  DRAGGABLE FLOATING WIDGET
// ══════════════════════════════════════════════════════
(function initFloatingWidget() {
  const WIDGET_ID   = "__xprd_widget";
  const HANDLE_ID   = "__xprd_handle";
  const IFRAME_ID   = "__xprd_iframe";
  const STORAGE_POS = "__xprd_pos";
  const STORAGE_VIS = "__xprd_vis";

  // Load saved position
  function getSavedPos() {
    try {
      const raw = localStorage.getItem(STORAGE_POS);
      if (raw) return JSON.parse(raw);
    } catch {}
    return null;
  }
  function savePos(x, y) {
    try { localStorage.setItem(STORAGE_POS, JSON.stringify({ x, y })); } catch {}
  }
  function getSavedVis() {
    try { return localStorage.getItem(STORAGE_VIS) !== "hidden"; } catch {}
    return true;
  }
  function saveVis(visible) {
    try { localStorage.setItem(STORAGE_VIS, visible ? "visible" : "hidden"); } catch {}
  }

  function clampPos(x, y, w, h) {
    const vw = window.innerWidth, vh = window.innerHeight;
    return {
      x: Math.max(0, Math.min(x, vw - w)),
      y: Math.max(0, Math.min(y, vh - 40))
    };
  }

  function createWidget() {
    if (document.getElementById(WIDGET_ID)) return;

    const savedPos = getSavedPos();
    const W = 480, H = 780;
    const defaultX = window.innerWidth - W - 20;
    const defaultY = 80;
    const startPos = savedPos
      ? clampPos(savedPos.x, savedPos.y, W, H)
      : { x: defaultX, y: defaultY };
    const startVisible = getSavedVis();

    // ── Shadow host ──
    const host = document.createElement("div");
    host.id = WIDGET_ID;
    host.style.cssText = `
      position: fixed !important;
      left: ${startPos.x}px !important;
      top: ${startPos.y}px !important;
      width: ${W}px !important;
      z-index: 2147483647 !important;
      font-family: sans-serif !important;
      filter: drop-shadow(0 8px 28px rgba(30,32,70,0.18)) !important;
    `;

    const shadow = host.attachShadow({ mode: "open" });

    // ── Inner HTML inside shadow DOM ──
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; margin: 0; padding: 0; }

        #container {
          width: 480px;
          border-radius: 12px;
          overflow: hidden;
          background: #ffffff;
          border: 1px solid #c9cce4;
          box-shadow: 0 2px 10px rgba(30,32,70,.08);
          display: flex;
          flex-direction: column;
          transition: height 0.25s cubic-bezier(.4,0,.2,1);
        }
        #container.collapsed { height: auto; }
        #container.expanded  { height: 780px; }

        /* drag handle / title bar */
        #handle {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 10px;
          height: 38px;
          background: #eceefa;
          border-bottom: 1px solid #dde0f0;
          cursor: grab;
          user-select: none;
          flex-shrink: 0;
        }
        #handle:active { cursor: grabbing; }
        #handle::after {
          content: '';
          position: absolute;
          bottom: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, #d9720a 30%, #d9720a 70%, transparent);
          opacity: .35;
        }
        #handle { position: relative; }

        #brand {
          display: flex;
          align-items: center;
          gap: 7px;
          pointer-events: none;
        }
        #brand svg { flex-shrink: 0; }
        #brand-text {
          font-family: 'Quicksand', 'Inter', sans-serif;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .18em;
          color: #b25e08;
        }

        #controls {
          display: flex;
          align-items: center;
          gap: 4px;
        }
        .ctrl-btn {
          width: 22px; height: 22px;
          border-radius: 4px;
          border: 1px solid #c9cce4;
          background: #f1f3fb;
          color: #6c709a;
          cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          font-size: 11px;
          transition: all .15s;
          flex-shrink: 0;
        }
        .ctrl-btn:hover { color: #b25e08; border-color: rgba(217,114,10,.4); background: rgba(217,114,10,.08); }
        .ctrl-btn.close:hover { color: #e0245e; border-color: rgba(224,36,94,.35); background: rgba(224,36,94,.06); }

        #body {
          flex: 1;
          overflow: hidden;
          position: relative;
        }
        #body.hidden { display: none; }

        #iframe-wrap {
          width: 100%;
          height: 100%;
          overflow: hidden;
          position: relative;
        }
        iframe {
          border: none;
          display: block;
          background: #ffffff;
          transform-origin: 0 0;
        }

        /* resize handle bottom-right */
        #resizer {
          position: absolute;
          right: 0; bottom: 0;
          width: 16px; height: 16px;
          cursor: nwse-resize;
          z-index: 10;
        }
        #resizer::after {
          content: '';
          position: absolute;
          right: 3px; bottom: 3px;
          width: 8px; height: 8px;
          border-right: 2px solid #6c709a;
          border-bottom: 2px solid #6c709a;
          border-radius: 1px;
        }
      </style>

      <div id="container" class="expanded">
        <div id="handle">
          <div id="brand">
            <img src="${chrome.runtime.getURL("icons/icon48.png")}" width="20" height="20" style="border-radius:5px;display:block;object-fit:cover" alt="Simba"/>
            <span id="brand-text">SIMBA'S PREDICTOR</span>
          </div>
          <div id="controls">
            <button class="ctrl-btn" id="btnShrink" title="Make smaller">－</button>
            <button class="ctrl-btn" id="btnGrow"   title="Make bigger">＋</button>
            <button class="ctrl-btn" id="btnCollapse" title="Collapse / Expand">▾</button>
            <button class="ctrl-btn close" id="btnClose" title="Close">✕</button>
          </div>
        </div>
        <div id="body">
          <div id="iframe-wrap">
            <iframe id="${IFRAME_ID}" src="${chrome.runtime.getURL("popup.html")}" allow="storage-access"></iframe>
          </div>
          <div id="resizer"></div>
        </div>
      </div>
    `;

    document.documentElement.appendChild(host);

    // ── Refs ──
    const container = shadow.getElementById("container");
    const handle    = shadow.getElementById("handle");
    const body      = shadow.getElementById("body");
    const btnCollapse = shadow.getElementById("btnCollapse");
    const btnClose    = shadow.getElementById("btnClose");
    const btnShrink   = shadow.getElementById("btnShrink");
    const btnGrow     = shadow.getElementById("btnGrow");

    // ── iframe scaling ──
    // The popup is designed at 340px wide. We scale it up to fill the widget.
    const POPUP_BASE_W = 340;
    const iframe = shadow.getElementById(IFRAME_ID);
    const iframeWrap = shadow.getElementById("iframe-wrap");

    function scaleIframe() {
      const availW = host.offsetWidth;
      const availH = parseInt(container.style.height || getComputedStyle(container).height) - 38;
      const scale = availW / POPUP_BASE_W;
      const iframeH = Math.round(availH / scale);
      iframe.style.width  = POPUP_BASE_W + "px";
      iframe.style.height = iframeH + "px";
      iframe.style.transform = `scale(${scale})`;
      iframeWrap.style.height = availH + "px";
    }

    // Scale once iframe loads, then on any size change
    iframe.addEventListener("load", scaleIframe);
    const resizeObs = new ResizeObserver(scaleIframe);
    resizeObs.observe(host);
    const SIZE_STEPS = [
      { w: 320, h: 520 },
      { w: 400, h: 640 },
      { w: 480, h: 780 },
      { w: 580, h: 900 },
      { w: 700, h: 1000 },
    ];
    function getCurrentStep() {
      const cw = host.offsetWidth;
      let closest = 0, minDiff = Infinity;
      SIZE_STEPS.forEach((s, i) => {
        const d = Math.abs(s.w - cw);
        if (d < minDiff) { minDiff = d; closest = i; }
      });
      return closest;
    }
    function applyStep(idx) {
      const s = SIZE_STEPS[idx];
      host.style.width = s.w + "px";
      container.style.height = s.h + "px";
      container.style.transition = "width .2s, height .2s";
      if (!collapsed) {
        savedHeight = s.h;
      }
      // keep widget on screen after resize
      const clamped = clampPos(host.offsetLeft, host.offsetTop, s.w, s.h);
      host.style.left = clamped.x + "px";
      host.style.top  = clamped.y + "px";
      savePos(host.offsetLeft, host.offsetTop);
      setTimeout(scaleIframe, 220); // after CSS transition
    }
    btnGrow.addEventListener("click", (e) => {
      e.stopPropagation();
      const next = Math.min(getCurrentStep() + 1, SIZE_STEPS.length - 1);
      applyStep(next);
    });
    btnShrink.addEventListener("click", (e) => {
      e.stopPropagation();
      const next = Math.max(getCurrentStep() - 1, 0);
      applyStep(next);
    });
    const resizer     = shadow.getElementById("resizer");

    // ── Collapse / expand ──
    let collapsed = false;
    let savedHeight = 600;
    function setCollapsed(val) {
      collapsed = val;
      if (collapsed) {
        savedHeight = parseInt(host.style.height) || 780;
        body.classList.add("hidden");
        container.classList.remove("expanded");
        container.classList.add("collapsed");
        btnCollapse.textContent = "▴";
        host.style.height = "auto";
      } else {
        body.classList.remove("hidden");
        container.classList.remove("collapsed");
        container.classList.add("expanded");
        btnCollapse.textContent = "▾";
        host.style.height = savedHeight + "px";
      }
    }
    btnCollapse.addEventListener("click", (e) => { e.stopPropagation(); setCollapsed(!collapsed); });

    // ── Close ──
    btnClose.addEventListener("click", (e) => {
      e.stopPropagation();
      host.style.display = "none";
      saveVis(false);
    });

    // ── Drag ──
    let dragging = false, dragOffX = 0, dragOffY = 0;

    handle.addEventListener("mousedown", (e) => {
      if (e.target.classList.contains("ctrl-btn")) return;
      dragging = true;
      dragOffX = e.clientX - host.offsetLeft;
      dragOffY = e.clientY - host.offsetTop;
      host.style.transition = "none";
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const W = host.offsetWidth, H = host.offsetHeight;
      let nx = e.clientX - dragOffX;
      let ny = e.clientY - dragOffY;
      const clamped = clampPos(nx, ny, W, H);
      host.style.left = clamped.x + "px";
      host.style.top  = clamped.y + "px";
    });

    document.addEventListener("mouseup", (e) => {
      if (!dragging) return;
      dragging = false;
      savePos(host.offsetLeft, host.offsetTop);
    });

    // ── Resize ──
    let resizing = false, resizeStartX = 0, resizeStartY = 0;
    let resizeStartW = 0, resizeStartH = 0;

    resizer.addEventListener("mousedown", (e) => {
      resizing = true;
      resizeStartX = e.clientX; resizeStartY = e.clientY;
      resizeStartW = host.offsetWidth;
      resizeStartH = parseInt(getComputedStyle(container).height) || 600;
      e.preventDefault(); e.stopPropagation();
    });

    document.addEventListener("mousemove", (e) => {
      if (!resizing) return;
      const newW = Math.max(360, resizeStartW + (e.clientX - resizeStartX));
      const newH = Math.max(300, resizeStartH + (e.clientY - resizeStartY));
      host.style.width = newW + "px";
      container.style.height = newH + "px";
      scaleIframe();
    });

    document.addEventListener("mouseup", () => {
      if (!resizing) return;
      resizing = false;
      savePos(host.offsetLeft, host.offsetTop);
    });

    // Apply saved visibility
    if (!startVisible) {
      host.style.display = "none";
    }

    // Toggle function exposed globally
    window.__xprdToggle = function() {
      if (host.style.display === "none") {
        host.style.display = "";
        saveVis(true);
      } else {
        if (collapsed) {
          setCollapsed(false);
        } else {
          setCollapsed(true);
        }
      }
    };
  }

  // Init widget as soon as DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", createWidget);
  } else {
    createWidget();
  }

  // Also listen for the toggle event fired by background.js
  window.addEventListener("__xprd_toggle", () => {
    if (typeof window.__xprdToggle === "function") window.__xprdToggle();
    else createWidget();
  });

})();
