// Simba's Predictor — Background Service Worker v5
const MAX_STORED = 500;
const seenIds = new Set();

// ══════════════════════════════════════════════════════
//  SELF-UPDATE CHECK
//  Since this extension isn't on the Chrome Web Store, it can't
//  silently auto-update the way store extensions do. Instead, this
//  polls a small JSON file you control and shows a banner in the
//  popup when a newer version is out. The person just re-downloads
//  the folder contents over the old ones and clicks the reload icon
//  on chrome://extensions — settings/history in chrome.storage are
//  untouched as long as the extension stays loaded from the same
//  folder path.
//
//  HOW TO SET THIS UP (one-time):
//  1. Host a small JSON file somewhere public, e.g. a GitHub Gist
//     (raw URL) or a "version.json" in a public GitHub repo. Example:
//     {
//       "version": "3.3.0",
//       "notes": "Fixed mine detector accuracy",
//       "download_url": "https://github.com/you/simbas-predictor/releases/latest"
//     }
//  2. Paste that raw JSON URL below as UPDATE_MANIFEST_URL.
//  3. Every time you ship an update: bump "version" in manifest.json
//     AND in that hosted JSON file to the same number, update
//     download_url if needed, and push. Anyone with the extension
//     installed will see the banner within a few hours (or right
//     away if they reopen the popup, since it also checks on open).
// ══════════════════════════════════════════════════════
const UPDATE_MANIFEST_URL = "PASTE_YOUR_HOSTED_VERSION_JSON_URL_HERE";

function compareVersions(a, b) {
  const pa = String(a).split(".").map(n => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const da = pa[i] || 0, db = pb[i] || 0;
    if (da > db) return 1;
    if (da < db) return -1;
  }
  return 0;
}

async function checkForUpdate() {
  if (!UPDATE_MANIFEST_URL || UPDATE_MANIFEST_URL.startsWith("PASTE_")) return;
  try {
    const res = await fetch(UPDATE_MANIFEST_URL, { cache: "no-store" });
    if (!res.ok) throw new Error("bad status " + res.status);
    const data = await res.json();
    const current = chrome.runtime.getManifest().version;
    const latest = String(data.version || "");
    if (!latest) return;
    const available = compareVersions(latest, current) > 0;
    chrome.storage.local.set({
      updateInfo: {
        available,
        latestVersion: latest,
        currentVersion: current,
        downloadUrl: data.download_url || "",
        notes: data.notes || "",
        checkedAt: Date.now()
      }
    });
  } catch (e) {
    // Quietly ignore — no network, bad URL not set up yet, etc.
  }
}

// Check on install/browser start, then every 6 hours
chrome.runtime.onInstalled.addListener(checkForUpdate);
chrome.runtime.onStartup.addListener(checkForUpdate);
chrome.alarms.create("xprd_update_check", { periodInMinutes: 360 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "xprd_update_check") checkForUpdate();
});

// ── Toggle floating widget on toolbar icon click ────────────
chrome.action.onClicked.addListener((tab) => {
  // Inject content script if not already there, then toggle the widget
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      if (typeof window.__xprdToggle === "function") {
        window.__xprdToggle();
      } else {
        // Widget not injected yet — content script will handle it
        window.dispatchEvent(new CustomEvent("__xprd_toggle"));
      }
    }
  }).catch(() => {});
});

async function getStoredFlips() {
  return new Promise(resolve => {
    chrome.storage.local.get(["flips"], (r) => resolve(r.flips || []));
  });
}

async function saveFlips(flips) {
  return new Promise(resolve => chrome.storage.local.set({ flips }, resolve));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === "ADD_FLIP") {
    chrome.storage.local.get(["flips"], (r) => {
      const flips = r.flips || [];
      if (message.id && seenIds.has(message.id)) {
        sendResponse && sendResponse({ success: false, reason: "duplicate" });
        return;
      }
      if (message.id) {
        seenIds.add(message.id);
        if (seenIds.size > 1000) seenIds.delete(seenIds.values().next().value);
      }
      flips.push({
        result:    message.result,
        id:        message.id || null,
        timestamp: message.timestamp || Date.now(),
        source:    message.source || "content"
      });
      if (flips.length > MAX_STORED) flips.splice(0, flips.length - MAX_STORED);
      chrome.storage.local.set({
        flips,
        apiStatus:   "ok",
        apiLastPoll: Date.now(),
        apiError:    null
      }, () => {
        chrome.runtime.sendMessage({ type: "NEW_FLIPS", count: 1, flips }).catch(() => {});
        sendResponse && sendResponse({ success: true, flips });
      });
    });
    return true;
  }

  if (message.type === "GET_FLIPS") {
    chrome.storage.local.get(["flips","apiStatus","apiLastPoll","apiError","apiRaw"], (r) => {
      sendResponse({
        flips:       r.flips       || [],
        apiStatus:   r.apiStatus   || "pending",
        apiLastPoll: r.apiLastPoll || null,
        apiError:    r.apiError    || null,
        apiRaw:      r.apiRaw      || null
      });
    });
    return true;
  }

  if (message.type === "GET_UPDATE_INFO") {
    chrome.storage.local.get(["updateInfo"], (r) => {
      sendResponse({ updateInfo: r.updateInfo || null });
    });
    return true;
  }

  if (message.type === "CHECK_FOR_UPDATE_NOW") {
    checkForUpdate().then(() => {
      chrome.storage.local.get(["updateInfo"], (r) => {
        sendResponse({ updateInfo: r.updateInfo || null });
      });
    });
    return true;
  }

  if (message.type === "GET_MINE_DATA") {
    chrome.storage.local.get(["mineData"], (r) => {
      sendResponse({ mineData: r.mineData || [] });
    });
    return true;
  }

  if (message.type === "ADD_MINE_DATA") {
    chrome.storage.local.get(["mineData","mineHeatmap"], (r) => {
      const mineData = r.mineData || [];
      const heatmap = r.mineHeatmap || {};
      
      mineData.unshift(message.data);
      if (mineData.length > 100) mineData.length = 100;
      
      if (message.data.bombs && message.data.bombs.length > 0) {
        for (const bomb of message.data.bombs) {
          if (!heatmap[bomb]) heatmap[bomb] = 0;
          heatmap[bomb]++;
        }
      }
      
      chrome.storage.local.set({ mineData, mineHeatmap: heatmap }, () => {
        chrome.runtime.sendMessage({ type: "NEW_MINE_DATA", count: mineData.length }).catch(() => {});
        sendResponse({ success: true });
      });
    });
    return true;
  }

  if (message.type === "CLEAR_FLIPS") {
    seenIds.clear();
    chrome.storage.local.set({ flips: [], lastSeenId: null }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "NEW_FLIPS") {
    sendResponse && sendResponse({ ok: true });
    return true;
  }

  if (message.type === "SAVE_API_KEY") {
    chrome.storage.local.set({ xpAnthropicKey: message.key }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "AI_ANALYZE") {
    chrome.storage.local.get(["xpAnthropicKey"], (r) => {
      const apiKey = (r.xpAnthropicKey || "").trim();
      if (!apiKey) {
        sendResponse({ error: "No API key set. Go to Settings → AI KEY and paste your Anthropic API key." });
        return;
      }
      fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
          "x-api-key": apiKey
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: message.prompt }]
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          sendResponse({ error: data.error.message || "API error" });
        } else {
          const text = (data.content || []).map(c => c.text || "").join("");
          sendResponse({ text });
        }
      })
      .catch(e => sendResponse({ error: e.message }));
    });
    return true;
  }

});

chrome.storage.local.get(["apiStatus"], (r) => {
  if (!r.apiStatus) {
    chrome.storage.local.set({
      apiStatus: "waiting",
      apiError: "Open bloxyspin.org to start receiving flips",
      apiLastPoll: null
    });
  }
});
