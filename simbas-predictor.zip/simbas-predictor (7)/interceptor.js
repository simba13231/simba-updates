// interceptor.js — runs in MAIN world (page's JS context)
// Has access to window.fetch, window.WebSocket etc.
// Communicates to content.js via window.postMessage

(function() {
  // ── Fetch intercept ──────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = async function(input, init, ...a) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const res = await _fetch.apply(this, [input, init, ...a]);
    if (url.includes("coinflip") || url.includes("flips") || url.includes("mine") || url.includes("pvp")) {
      try {
        const clone = res.clone();
        const parsed = await clone.json();
        // Filter flips to only completed (active: false, winnercoin present)
        if (parsed && parsed.data && Array.isArray(parsed.data) && url.includes("coinflip")) {
          parsed.data = parsed.data.filter(f => f.active === false && f.winnercoin);
        }
        // Don't filter mines - pass all through
        window.postMessage({ __xprd: true, type: "fetch", payload: parsed, url }, "*");
      } catch {}
    }
    return res;
  };

  // ── XHR intercept ───────────────────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...a) {
    this._xpUrl = url;
    return _open.apply(this, [method, url, ...a]);
  };
  XMLHttpRequest.prototype.send = function(...a) {
    this.addEventListener("load", function() {
      if (this._xpUrl && (this._xpUrl.includes("coinflip") || this._xpUrl.includes("flips"))) {
        try {
          const parsed = JSON.parse(this.responseText);
          window.postMessage({ __xprd: true, type: "xhr", payload: parsed, url: this._xpUrl }, "*");
        } catch {}
      }
    });
    return _send.apply(this, a);
  };

  // ── WebSocket intercept ──────────────────────────────
  const _WS = window.WebSocket;
  window.WebSocket = function(url, protocols) {
    const ws = protocols ? new _WS(url, protocols) : new _WS(url);
    ws.addEventListener("message", function(e) {
      try {
        let data = e.data;
        if (typeof data !== "string") return;
        // Strip Socket.IO prefix e.g. "42["event", {...}]"
        const match = data.match(/^\d+(\/[^,]+,)?(\[.*\])$/s);
        if (match) data = match[2];
        const parsed = JSON.parse(data);
        window.postMessage({ __xprd: true, type: "ws", payload: parsed, url: url }, "*");
      } catch {}
    });
    return ws;
  };
  Object.setPrototypeOf(window.WebSocket, _WS);
  Object.assign(window.WebSocket, _WS);

})();
