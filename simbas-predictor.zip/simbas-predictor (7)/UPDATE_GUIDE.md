# How updates work for this extension

This isn't on the Chrome Web Store, so it can't silently auto-update the
way store extensions do. Here's the setup that gets you as close as
possible: people install once, and after that they just need to overwrite
files + hit reload — no re-installing, no losing their saved flip history
or settings.

## One-time setup (you do this once)

1. Host a tiny JSON file somewhere public and stable. Easiest option:
   a public GitHub repo or Gist. Example file (`version.json`):

   ```json
   {
     "version": "3.3.0",
     "notes": "Fixed mine detector accuracy",
     "download_url": "https://github.com/you/simbas-predictor/releases/latest"
   }
   ```

2. Copy that file's **raw** URL (e.g.
   `https://raw.githubusercontent.com/you/simbas-predictor/main/version.json`
   or a Gist's raw URL).

3. Open `background.js` and paste it in near the top:

   ```js
   const UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/you/.../version.json";
   ```

4. Rezip and send this folder to people once. They load it via
   "Load unpacked" in `chrome://extensions` (dev mode on).

## Every time you ship a change

1. Bump `"version"` in `manifest.json` (e.g. `3.2.0` → `3.3.0`).
2. Bump `"version"` in your hosted `version.json` to the **same** number,
   update `notes` and `download_url`, push it.
3. Send the updated folder / zip to people (same way you sent it the
   first time — Discord, Drive link, wherever).

## What people on the other end do

- Within a few hours (it checks every 6 hours, plus every time they open
  the popup), they'll see a green banner at the top: "UPDATE AVAILABLE —
  v3.3.0 · GET UPDATE →". Clicking it opens your `download_url`.
- To actually apply it: unzip the new files **over** the old folder
  (same path, overwrite), go to `chrome://extensions`, and click the small
  circular reload icon on the extension's card. That's it — no "Remove"
  + "Load unpacked" again, and `chrome.storage` data (flip history,
  settings, saved sessions) is untouched.

## The one thing that resets storage

An unpacked extension's ID is derived from the **folder's file path**.
If someone moves or renames the folder, Chrome treats it as a new
extension and their saved data starts over. As long as they keep
overwriting the same folder in place, this won't happen.
