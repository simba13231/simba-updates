// Simba's Predictor v5.0 — popup.js
// Enhanced prediction engine + animated UI

// ══════════════════════════════════════════════════════
//  SETTINGS
// ══════════════════════════════════════════════════════
const DEFAULT_CFG = {
  useMarkov:true,useStreak:true,usePattern:true,useGlobal:true,
  showChips:true,animations:true,maxFlips:500,pollInterval:4,
  bannerAlerts:true,soundAlerts:false,recThreshold:75,
  autoBetLogger:true,notificationsEnabled:false,showTimestamps:false,
  autoJoin:false,autoJoinThreshold:75,autoJoinDelay:1200,autoJoinMin:100000,autoJoinMax:200000000,
  autoJoinGiveaway:false,autoJoinGiveawayDelay:800
};
let cfg = {...DEFAULT_CFG};

async function loadSettings(){
  return new Promise(resolve=>{
    chrome.storage.local.get(["xpSettings"],r=>{
      if(r.xpSettings) cfg={...DEFAULT_CFG,...r.xpSettings};
      resolve();
    });
  });
}
function saveSettings(){chrome.storage.local.set({xpSettings:cfg});}

// ══════════════════════════════════════════════════════
//  PER-MODEL ACCURACY TRACKING
// ══════════════════════════════════════════════════════
let modelAccuracy = {};
let lastPrediction = null;
let mineEvents = [];

function loadModelAccuracy(){
  chrome.storage.local.get(["xpModelAccuracy"],r=>{
    if(r.xpModelAccuracy) modelAccuracy = r.xpModelAccuracy;
  });
}
function saveModelAccuracy(){ chrome.storage.local.set({xpModelAccuracy: modelAccuracy}); }

function recordModelOutcomes(pred, actualResult){
  if(!pred || !pred.models) return;
  pred.models.forEach(m => {
    if(m.weight <= 0) return;
    if(!modelAccuracy[m.name]) modelAccuracy[m.name] = {correct:0, total:0};
    modelAccuracy[m.name].total++;
    const modelPredicted = m.vote >= 0.5 ? "heads" : "tails";
    if(modelPredicted === actualResult) modelAccuracy[m.name].correct++;
  });
  saveModelAccuracy();
}

// ══════════════════════════════════════════════════════
//  CALIBRATION
// ══════════════════════════════════════════════════════
let calibrationData = [];
function loadCalibration(){ chrome.storage.local.get(["xpCalibration"],r=>{ if(r.xpCalibration) calibrationData = r.xpCalibration; }); }
function saveCalibration(){ chrome.storage.local.set({xpCalibration: calibrationData}); }
function recordCalibration(confidence, correct){
  calibrationData.push({confidence, correct, time: Date.now()});
  if(calibrationData.length > 200) calibrationData.shift();
  saveCalibration();
}

// ══════════════════════════════════════════════════════
//  SESSIONS
// ══════════════════════════════════════════════════════
let savedSessions = [];
function loadSavedSessions(){ chrome.storage.local.get(["xpSavedSessions"],r=>{ if(r.xpSavedSessions) savedSessions = r.xpSavedSessions; }); }
function saveSavedSessions(){ chrome.storage.local.set({xpSavedSessions: savedSessions}); }
function archiveCurrentSession(){
  if(!betLog.length) return;
  const wins = betLog.filter(b=>b.win).length;
  const session = {
    id: Date.now(),
    name: "Session " + new Date().toLocaleDateString([],{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),
    flips: betLog.length, wins, losses: betLog.length - wins,
    accuracy: Math.round(wins/betLog.length*100),
    bestWin: currentBestWin, worstLoss: currentWorstLoss, time: Date.now()
  };
  savedSessions.unshift(session);
  if(savedSessions.length > 10) savedSessions.pop();
  saveSavedSessions();
}

// ══════════════════════════════════════════════════════
//  ENHANCED PREDICTION ENGINE v2
// ══════════════════════════════════════════════════════
function toBin(results){ return results.map(r=>r==="heads"?1:0); }

// Dynamic model weighting based on recent accuracy
function getDynamicWeight(modelName, baseWeight){
  const m = modelAccuracy[modelName];
  if(!m || m.total < 10) return baseWeight;
  const acc = m.correct / m.total;
  // Boost models that are > 55%, penalize models < 45%
  const multiplier = acc > 0.55 ? 1 + (acc - 0.55) * 3 : acc < 0.45 ? Math.max(0.1, 1 - (0.45 - acc) * 3) : 1;
  return baseWeight * multiplier;
}

const MODELS = {
  markov(bin){
    if(bin.length<8) return{vote:.5,weight:0,name:"MARKOV CHAIN"};
    // 2nd order
    const t={};
    for(let i=0;i<bin.length-2;i++){
      const k=`${bin[i]},${bin[i+1]}`;
      if(!t[k])t[k]={h:0,n:0};
      t[k].h+=bin[i+2];t[k].n++;
    }
    const k=`${bin[bin.length-2]},${bin[bin.length-1]}`,tr=t[k];
    if(!tr||tr.n<3) return{vote:.5,weight:.2,name:"MARKOV CHAIN"};
    const p=tr.h/tr.n;
    const baseW = .4+Math.abs(p-.5)*1.2;
    const w = getDynamicWeight("MARKOV CHAIN", baseW);
    return{vote:p,weight:w,name:"MARKOV CHAIN",detail:`state→${Math.round(p*100)}%H (n=${tr.n})`};
  },

  markov3(bin){
    // 3rd order Markov for deeper pattern memory
    if(bin.length<15) return{vote:.5,weight:0,name:"DEEP MARKOV"};
    const t={};
    for(let i=0;i<bin.length-3;i++){
      const k=`${bin[i]},${bin[i+1]},${bin[i+2]}`;
      if(!t[k])t[k]={h:0,n:0};
      t[k].h+=bin[i+3];t[k].n++;
    }
    const k=`${bin[bin.length-3]},${bin[bin.length-2]},${bin[bin.length-1]}`,tr=t[k];
    if(!tr||tr.n<2) return{vote:.5,weight:0,name:"DEEP MARKOV"};
    const p=tr.h/tr.n;
    const baseW = .35+Math.abs(p-.5)*1.4;
    const w = getDynamicWeight("DEEP MARKOV", baseW);
    return{vote:p,weight:w,name:"DEEP MARKOV",detail:`depth-3→${Math.round(p*100)}%H (n=${tr.n})`};
  },

  streak(bin){
    if(bin.length<4) return{vote:.5,weight:0,name:"STREAK"};
    let streak=1;const last=bin[bin.length-1];
    for(let i=bin.length-2;i>=0;i--){if(bin[i]===last)streak++;else break;}
    if(streak<=1) return{vote:.5,weight:0,name:"STREAK"};
    const tbl=[[.5,0],[.54,.35],[.54,.35],[.46,.6],[.41,.72],[.37,.85],[.34,.9]];
    const [vBase,bw]=tbl[Math.min(streak-1,6)];
    const vote=last===1?vBase:1-vBase;
    const w = getDynamicWeight("STREAK", bw);
    return{vote,weight:w,name:"STREAK",detail:`${streak}× ${last?"H":"T"} → ${streak>=4?"reversal":"continue"}`};
  },

  window(bin){
    const w50=bin.slice(-50),w20=bin.slice(-20),w10=bin.slice(-10);
    if(w50.length<10) return{vote:.5,weight:0,name:"WINDOW BIAS"};
    const r50=w50.reduce((a,b)=>a+b,0)/w50.length;
    const r20=w20.length>=10?w20.reduce((a,b)=>a+b,0)/w20.length:r50;
    const r10=w10.length>=5?w10.reduce((a,b)=>a+b,0)/w10.length:r20;
    // Weight recent more heavily
    const blended = r10*0.5 + r20*0.3 + r50*0.2;
    const drift = blended - 0.5;
    const baseW = Math.abs(drift)>.06 ? .3+Math.abs(drift)*1.8 : 0;
    const w = getDynamicWeight("WINDOW BIAS", baseW);
    return{vote:.5-drift*.7,weight:w,name:"WINDOW BIAS",detail:`${Math.round(blended*100)}%H (10/20/50)`};
  },

  alternation(bin){
    const w=bin.slice(-20);
    if(w.length<8) return{vote:.5,weight:0,name:"ALTERNATION"};
    let alts=0;
    for(let i=1;i<w.length;i++) if(w[i]!==w[i-1]) alts++;
    const ar=alts/(w.length-1),last=bin[bin.length-1];
    if(ar>.70) return{vote:last?.28:.72,weight:getDynamicWeight("ALTERNATION",.35+(ar-.5)*1.6),name:"ALTERNATION",detail:`${Math.round(ar*100)}% alt → flip`};
    if(ar<.30) return{vote:last?.72:.28,weight:getDynamicWeight("ALTERNATION",.35+(.5-ar)*1.6),name:"ALTERNATION",detail:`${Math.round(ar*100)}% alt → hold`};
    return{vote:.5,weight:0,name:"ALTERNATION"};
  },

  pattern(bin){
    if(bin.length<12) return{vote:.5,weight:0,name:"PATTERN REPEAT"};
    const tail=bin.slice(-40);
    let bestScore=0,bestVote=.5,bestDetail="";
    for(let len=2;len<=8;len++){
      const pat=tail.slice(-len);let matches=0,hf=0;
      for(let i=0;i<=tail.length-len-1;i++){
        if(pat.every((v,j)=>tail[i+j]===v)){matches++;if(tail[i+len]===1)hf++;}
      }
      if(matches>=3){
        const p=hf/matches,s=matches*Math.abs(p-.5)*1.2;
        if(s>bestScore){bestScore=s;bestVote=p;bestDetail=`${len}-flip pattern ×${matches}`;}
      }
    }
    if(bestScore<.8) return{vote:.5,weight:0,name:"PATTERN REPEAT"};
    const bw = Math.min(bestScore*.28,.95);
    return{vote:bestVote,weight:getDynamicWeight("PATTERN REPEAT",bw),name:"PATTERN REPEAT",detail:bestDetail};
  },

  // NEW: Bayesian frequency model
  bayesian(bin){
    if(bin.length<20) return{vote:.5,weight:0,name:"BAYESIAN"};
    // Use last 30 with exponential decay weights
    const w=bin.slice(-30);
    let wSum=0,hSum=0;
    w.forEach((v,i)=>{
      const weight=Math.exp((i-w.length+1)*0.1); // exponential decay
      wSum+=weight; hSum+=v*weight;
    });
    const p=hSum/wSum;
    const drift=Math.abs(p-.5);
    if(drift<.06) return{vote:.5,weight:0,name:"BAYESIAN"};
    const bw = getDynamicWeight("BAYESIAN",.25+drift*2);
    return{vote:p,weight:bw,name:"BAYESIAN",detail:`decay-weighted ${Math.round(p*100)}%H`};
  },

  // NEW: Entropy/volatility model — detects when series is "due" for a change
  volatility(bin){
    if(bin.length<15) return{vote:.5,weight:0,name:"VOLATILITY"};
    const w=bin.slice(-20);
    // Calculate local entropy
    let runs=1;
    for(let i=1;i<w.length;i++) if(w[i]!==w[i-1]) runs++;
    const expectedRuns=w.length/2;
    const runRatio=runs/expectedRuns;
    // Low runs = highly clumped, high runs = highly alternating
    // Neither extreme is sustainable — predict regression toward mean
    const last=bin[bin.length-1];
    if(runRatio<0.6){
      // Too clumped — reversal likely
      return{vote:last?0.35:0.65,weight:getDynamicWeight("VOLATILITY",.3),name:"VOLATILITY",detail:`clumped (${runs} runs) → flip`};
    }
    if(runRatio>1.5){
      // Too alternating — clump likely
      return{vote:last?0.65:0.35,weight:getDynamicWeight("VOLATILITY",.3),name:"VOLATILITY",detail:`volatile (${runs} runs) → hold`};
    }
    return{vote:.5,weight:0,name:"VOLATILITY"};
  }
};

// Conflict detection
function detectConflicts(models){
  const active = models.filter(m=>m.weight>0.2);
  if(active.length<2) return false;
  const hVotes = active.filter(m=>m.vote>=0.5).length;
  const tVotes = active.length - hVotes;
  // Conflict if roughly half say H, half say T
  return Math.min(hVotes,tVotes)/active.length >= 0.4;
}

function computePrediction(flips,cfg){
  if(flips.length<5) return{result:null,confidence:50,models:[],conflict:false};
  const bin=toBin(flips.map(f=>f.result));
  const results=[
    cfg.useMarkov?MODELS.markov(bin):{vote:.5,weight:0,name:"MARKOV CHAIN"},
    cfg.useMarkov?MODELS.markov3(bin):{vote:.5,weight:0,name:"DEEP MARKOV"},
    cfg.useStreak?MODELS.streak(bin):{vote:.5,weight:0,name:"STREAK"},
    cfg.useGlobal?MODELS.window(bin):{vote:.5,weight:0,name:"WINDOW BIAS"},
    MODELS.alternation(bin),
    cfg.usePattern?MODELS.pattern(bin):{vote:.5,weight:0,name:"PATTERN REPEAT"},
    MODELS.bayesian(bin),
    MODELS.volatility(bin),
  ];

  const conflict = detectConflicts(results);

  let tw=0,wv=0;
  results.forEach(m=>{tw+=m.weight;wv+=m.vote*m.weight;});
  const combined=tw>0?wv/tw:.5;

  // Penalise confidence when models conflict
  let confidence=Math.round(50+Math.abs(combined-.5)*100);
  if(conflict) confidence=Math.round(50+(confidence-50)*0.65);

  const result=combined>=.5?"heads":"tails";
  const agreeing=results.filter(m=>m.weight>0.2&&(m.vote>=.5?result==="heads":result==="tails")).length;
  const active=results.filter(m=>m.weight>0.2).length;

  return{result:confidence>50?result:null,confidence,models:results,conflict,agreeing,active};
}

// Pattern fingerprint: find exact last-N sequence and what followed historically
function getFingerprint(flips, n=5){
  if(flips.length < n+3) return null;
  const bin = toBin(flips.map(f=>f.result));
  const tail = bin.slice(-n);
  let hAfter=0,tAfter=0;
  for(let i=0;i<=bin.length-n-1;i++){
    if(tail.every((v,j)=>bin[i+j]===v)){
      bin[i+n]===1?hAfter++:tAfter++;
    }
  }
  const total=hAfter+tAfter;
  if(total<2) return null;
  return{
    pattern:tail.map(v=>v?"H":"T").join(""),
    hAfter,tAfter,total,
    hPct:Math.round(hAfter/total*100),
    predicted: hAfter>tAfter?"heads":"tails"
  };
}

function getStreak(flips){
  if(!flips.length) return{count:0,side:null};
  let count=1;const side=flips[flips.length-1].result;
  for(let i=flips.length-2;i>=0;i--){if(flips[i].result===side)count++;else break;}
  return{count,side};
}
function longestStreak(flips,side){ let max=0,cur=0;flips.forEach(f=>{f.result===side?cur++:cur=0;if(cur>max)max=cur;});return max; }
function altRate(flips){ if(flips.length<2) return .5;let a=0;for(let i=1;i<flips.length;i++) if(flips[i].result!==flips[i-1].result) a++;return a/(flips.length-1); }
function avgRunLen(flips){ if(!flips.length) return 0;let runs=1;for(let i=1;i<flips.length;i++) if(flips[i].result!==flips[i-1].result) runs++;return flips.length/runs; }
function timeSince(ts){ if(!ts) return "";const s=Math.floor((Date.now()-ts)/1000);if(s<60) return s+"s ago";if(s<3600) return Math.floor(s/60)+"m ago";return Math.floor(s/3600)+"h ago"; }

// ══════════════════════════════════════════════════════
//  AUTO-BET LOGGER
// ══════════════════════════════════════════════════════
let betLog=[], currentBestWin=0, currentWorstLoss=0;
let currentWinStreak=0, currentLossStreak=0, totalCorrect=0, totalBets=0;
let pendingPrediction=null, lastFlipCountForAuto=0, lastPredConfidence=50;

function loadBetLog(){
  chrome.storage.local.get(["xpBetLog","xpBetStats"],r=>{
    if(r.xpBetLog) betLog=r.xpBetLog;
    if(r.xpBetStats){totalCorrect=r.xpBetStats.totalCorrect||0;totalBets=r.xpBetStats.totalBets||0;currentBestWin=r.xpBetStats.bestWin||0;currentWorstLoss=r.xpBetStats.worstLoss||0;}
  });
}
function saveBetLog(){ chrome.storage.local.set({xpBetLog:betLog,xpBetStats:{totalCorrect,totalBets,bestWin:currentBestWin,worstLoss:currentWorstLoss}}); }

function autoLogBet(predicted,actual,confidence,pred){
  const win=predicted===actual;
  betLog.unshift({predicted,actual,win,confidence,time:Date.now()});
  if(betLog.length>100) betLog.pop();
  totalBets++;
  if(win){totalCorrect++;currentWinStreak++;currentLossStreak=0;if(currentWinStreak>currentBestWin)currentBestWin=currentWinStreak;}
  else{currentLossStreak++;currentWinStreak=0;if(currentLossStreak>currentWorstLoss)currentWorstLoss=currentLossStreak;}
  recordModelOutcomes(pred,actual);
  recordCalibration(confidence,win);
  saveBetLog();
  renderAccuracy();
  if(cfg.notificationsEnabled){
    chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"icons/icon48.png",title:win?"✓ Prediction Correct!":"✗ Prediction Wrong",message:`${predicted.toUpperCase()} predicted, ${actual.toUpperCase()} landed. Accuracy: ${Math.round(totalCorrect/totalBets*100)}%`});
  }
}

function renderAccuracy(){
  const acc=totalBets>0?Math.round(totalCorrect/totalBets*100):null;
  const el=document.getElementById("overallAccuracy");if(el)el.textContent=acc!==null?acc+"%":"—";
  const sub=document.getElementById("accuracySub");if(sub)sub.textContent=totalBets>0?`${totalCorrect}/${totalBets} correct (70%+ signals only)`:"Waiting for 70%+ confidence predictions";
  const el2=document.getElementById("statAccuracy");
  if(el2){el2.textContent=acc!==null?acc+"%":"—";el2.style.color=acc===null?"var(--muted)":acc>=55?"var(--heads)":acc<=45?"var(--tails)":"var(--x)";}
  renderBetLog();renderCalibrationChart();renderModelAccuracy();renderSessions();
  // Update live accuracy chip on predict tab
  const chip=document.getElementById("liveAccChip");
  if(chip) chip.textContent=acc!==null?`${acc}% ACC (${totalBets})`: "ACC —";
}

function renderBetLog(){
  const log=document.getElementById("betLogList");if(!log)return;
  if(!betLog.length){log.innerHTML=`<div class="bet-empty">No auto-logged bets yet.</div>`;return;}
  log.innerHTML="";
  betLog.slice(0,40).forEach(b=>{
    const row=document.createElement("div");row.className="bet-row";
    const t=new Date(b.time).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
    row.innerHTML=`<span class="bet-side ${b.predicted==="heads"?"h":"t"}">${b.predicted==="heads"?"H":"T"}</span><span class="bet-conf-badge">${b.confidence||"?"}%</span><span class="bet-actual">→ ${b.actual.toUpperCase()}</span><span class="bet-result ${b.win?"win":"loss"}">${b.win?"✓":"✗"}</span><span class="bet-time">${t}</span>`;
    log.appendChild(row);
  });
}

function renderCalibrationChart(){
  const el=document.getElementById("calibChart");if(!el||!calibrationData.length)return;
  const bands=[{label:"50-55",min:50,max:55,correct:0,total:0},{label:"55-60",min:55,max:60,correct:0,total:0},{label:"60-65",min:60,max:65,correct:0,total:0},{label:"65-70",min:65,max:70,correct:0,total:0},{label:"70-75",min:70,max:75,correct:0,total:0},{label:"75-80",min:75,max:80,correct:0,total:0},{label:"80+",min:80,max:100,correct:0,total:0}];
  calibrationData.forEach(d=>{const band=bands.find(b=>d.confidence>=b.min&&d.confidence<b.max)||bands[bands.length-1];band.total++;if(d.correct)band.correct++;});
  el.innerHTML="";
  bands.forEach(b=>{
    const pct=b.total>0?Math.round(b.correct/b.total*100):null;
    const bar=document.createElement("div");bar.className="calib-col";
    const side=pct===null?"n":pct>=55?"h":"t";
    bar.innerHTML=`<div class="calib-pct">${pct!==null?pct+"%":"—"}</div><div class="calib-bar-wrap"><div class="calib-bar ${side}" style="height:${pct!==null?pct:0}%"></div><div class="calib-expected"></div></div><div class="calib-label">${b.label}</div><div class="calib-n">${b.total>0?"n="+b.total:""}</div>`;
    el.appendChild(bar);
  });
}

function renderModelAccuracy(){
  const el=document.getElementById("modelAccList");if(!el)return;
  const names=["MARKOV CHAIN","DEEP MARKOV","STREAK","WINDOW BIAS","ALTERNATION","PATTERN REPEAT","BAYESIAN","VOLATILITY"];
  if(!Object.keys(modelAccuracy).length){el.innerHTML=`<div style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--muted);padding:8px 0">Auto-logging predictions to build accuracy data...</div>`;return;}
  el.innerHTML="";
  names.forEach(name=>{
    const m=modelAccuracy[name];if(!m||m.total===0)return;
    const acc=Math.round(m.correct/m.total*100);
    const row=document.createElement("div");row.className="model-row";
    const side=acc>=55?"h":acc<=45?"t":"n";
    row.innerHTML=`<div class="model-top"><span class="model-name">${name}</span><span class="model-vote ${side}">${acc}% ACC</span></div><div class="model-bar-wrap"><div class="model-bar ${side}" style="width:${acc}%"></div></div><div class="model-weight">${m.correct}/${m.total} correct · ${acc>=55?"🔥 HOT":acc<=45?"❄ COLD":"NEUTRAL"}</div>`;
    el.appendChild(row);
  });
}

// ══════════════════════════════════════════════════════
//  SESSIONS
// ══════════════════════════════════════════════════════
function renderSessions(){
  const el=document.getElementById("sessionsList");if(!el)return;
  if(!savedSessions.length){el.innerHTML=`<div class="bet-empty">No saved sessions yet.</div>`;return;}
  el.innerHTML="";
  savedSessions.forEach(s=>{
    const row=document.createElement("div");row.className="sess-row";
    const date=new Date(s.time).toLocaleDateString([],{month:"short",day:"numeric"});
    row.innerHTML=`<div class="sess-name">${s.name}</div><div class="sess-stats"><span class="sess-acc ${s.accuracy>=55?"pos":s.accuracy<=45?"neg":"neu"}">${s.accuracy}%</span><span class="sess-detail">${s.wins}W / ${s.losses}L · ${s.flips} flips · ${date}</span></div><div class="sess-bar-wrap"><div class="sess-bar-fill" style="width:${s.accuracy}%;background:${s.accuracy>=55?"var(--heads)":s.accuracy<=45?"var(--tails)":"var(--x)"}"></div></div>`;
    el.appendChild(row);
  });
}

// ══════════════════════════════════════════════════════
//  CSV EXPORT
// ══════════════════════════════════════════════════════
function exportCSV(flips){
  const rows=[["id","result","timestamp","source","datetime"]];
  flips.forEach(f=>rows.push([f.id||"",f.result,f.timestamp||"",f.source||"",f.timestamp?new Date(f.timestamp).toISOString():""]));
  const csv=rows.map(r=>r.join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download=`xpredictions_${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(url);
}

// ══════════════════════════════════════════════════════
//  COOLDOWN ENFORCER
// ══════════════════════════════════════════════════════
let cooldownActive=false;
function checkCooldown(confidence){
  const overlay=document.getElementById("cooldownOverlay");if(!overlay)return;
  if(confidence<57){if(!cooldownActive){cooldownActive=true;overlay.style.display="flex";}}
  else{if(cooldownActive){cooldownActive=false;overlay.style.display="none";}}
}

// ══════════════════════════════════════════════════════
//  ANIMATED CONFIDENCE GAUGE (SVG arc)
// ══════════════════════════════════════════════════════
let gaugeAnimFrame=null;
let gaugeTarget=50, gaugeCurrent=50;

function animateGauge(target){
  gaugeTarget=target;
  if(gaugeAnimFrame) return;
  function step(){
    const diff=gaugeTarget-gaugeCurrent;
    if(Math.abs(diff)<0.5){gaugeCurrent=gaugeTarget;drawGauge(gaugeCurrent);gaugeAnimFrame=null;return;}
    gaugeCurrent+=diff*0.12;
    drawGauge(gaugeCurrent);
    gaugeAnimFrame=requestAnimationFrame(step);
  }
  gaugeAnimFrame=requestAnimationFrame(step);
}

function drawGauge(pct){
  const canvas=document.getElementById("confGaugeCanvas");if(!canvas)return;
  const ctx=canvas.getContext("2d");
  const W=canvas.width,H=canvas.height;
  const cx=W/2,cy=H*0.72,r=W*0.38;
  ctx.clearRect(0,0,W,H);

  // Background arc
  ctx.beginPath();ctx.arc(cx,cy,r,Math.PI,2*Math.PI);
  ctx.strokeStyle="rgba(255,255,255,0.06)";ctx.lineWidth=10;ctx.lineCap="round";ctx.stroke();

  // Colored fill arc
  const fraction=Math.max(0,Math.min((pct-50)/50,1));
  const startAngle=Math.PI;
  const endAngle=Math.PI+fraction*Math.PI;
  const col=pct>=75?"#00f5a0":pct>=63?"#d9720a":pct>=57?"#ffb347":"#ff3d6e";

  ctx.beginPath();ctx.arc(cx,cy,r,startAngle,endAngle);
  ctx.strokeStyle=col;ctx.lineWidth=10;ctx.lineCap="round";ctx.stroke();

  // Glow
  ctx.beginPath();ctx.arc(cx,cy,r,startAngle,endAngle);
  ctx.strokeStyle=col+"55";ctx.lineWidth=18;ctx.stroke();

  // Tick marks
  for(let i=0;i<=10;i++){
    const a=Math.PI+i/10*Math.PI;
    const inner=r-14,outer=r-6;
    ctx.beginPath();
    ctx.moveTo(cx+Math.cos(a)*inner,cy+Math.sin(a)*inner);
    ctx.lineTo(cx+Math.cos(a)*outer,cy+Math.sin(a)*outer);
    ctx.strokeStyle="rgba(255,255,255,0.12)";ctx.lineWidth=1.5;ctx.stroke();
  }

  // Needle
  const needleAngle=Math.PI+fraction*Math.PI;
  const nx=cx+Math.cos(needleAngle)*(r-20);
  const ny=cy+Math.sin(needleAngle)*(r-20);
  ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(nx,ny);
  ctx.strokeStyle=col;ctx.lineWidth=2.5;ctx.lineCap="round";ctx.stroke();
  ctx.beginPath();ctx.arc(cx,cy,5,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();

  // Pct label
  ctx.font="bold 20px 'Orbitron',monospace";ctx.fillStyle=col;ctx.textAlign="center";ctx.textBaseline="middle";
  ctx.fillText(Math.round(pct)+"%",cx,cy-r*0.35);

  // Min/max labels
  ctx.font="9px 'Share Tech Mono',monospace";ctx.fillStyle="rgba(255,255,255,0.25)";
  ctx.fillText("50%",cx-r-4,cy+14);ctx.fillText("100%",cx+r+2,cy+14);
}

// ══════════════════════════════════════════════════════
//  CONFIDENCE SPARKLINE
// ══════════════════════════════════════════════════════
let confHistory=[], prevConfidence=50, confidenceDelta=0;

function updateSparkline(){
  const canvas=document.getElementById("confSparkCanvas");if(!canvas||confHistory.length<2)return;
  const ctx=canvas.getContext("2d");
  const W=canvas.width,H=canvas.height;
  ctx.clearRect(0,0,W,H);
  const min=Math.max(50,Math.min(...confHistory)-2);
  const max=Math.min(100,Math.max(...confHistory)+2);
  const range=Math.max(max-min,5);
  const pts=confHistory.map((c,i)=>({x:i/(confHistory.length-1)*(W-4)+2,y:H-2-(c-min)/range*(H-4)}));
  // Fill
  const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,"rgba(232,255,0,0.2)");grad.addColorStop(1,"rgba(232,255,0,0)");
  ctx.beginPath();ctx.moveTo(pts[0].x,H);pts.forEach(p=>ctx.lineTo(p.x,p.y));ctx.lineTo(pts[pts.length-1].x,H);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
  // Line
  ctx.beginPath();pts.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y));
  ctx.strokeStyle="rgba(217,114,10,0.7)";ctx.lineWidth=1.5;ctx.stroke();
  // Last dot
  const last=pts[pts.length-1];
  ctx.beginPath();ctx.arc(last.x,last.y,3,0,Math.PI*2);ctx.fillStyle="#d9720a";ctx.fill();
}

// ══════════════════════════════════════════════════════
//  ALERTS
// ══════════════════════════════════════════════════════
let recommendedFlips=[],alertCount=0,lastAlertPred=null,soundEnabled=false;

function playAlert(){
  try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const osc=ctx.createOscillator();const gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);osc.frequency.setValueAtTime(880,ctx.currentTime);osc.frequency.setValueAtTime(1100,ctx.currentTime+0.1);gain.gain.setValueAtTime(0.3,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.4);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.4);}catch(e){}
}
function playFlipTick(){
  try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const osc=ctx.createOscillator();const gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);osc.frequency.value=600;gain.gain.setValueAtTime(0.08,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.06);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.06);}catch(e){}
}

function getTierClass(c){ if(c>=80)return"tier-strong";if(c>=70)return"tier-good";if(c>=63)return"tier-moderate";return"tier-weak"; }

function checkAndAddRecommended(pred,flips){
  const threshold=cfg.recThreshold||75;
  if(!pred.result||pred.confidence<threshold) return;
  const key=pred.result+"-"+pred.confidence+"-"+flips.length;
  if(lastAlertPred===key) return;
  lastAlertPred=key;
  const rec={id:Date.now(),result:pred.result,confidence:pred.confidence,tierClass:getTierClass(pred.confidence),signals:pred.models.filter(m=>m.weight>0.2&&m.detail).map(m=>({name:m.name,detail:m.detail,side:m.vote>=.5?"h":"t"})),time:Date.now()};
  recommendedFlips.unshift(rec);if(recommendedFlips.length>20)recommendedFlips.pop();
  alertCount++;renderRecommended();
  const badge=document.getElementById("alertBadge");if(badge){badge.style.display="inline";badge.textContent=alertCount;}
  if(soundEnabled)playAlert();
  if(cfg.bannerAlerts){
    const banner=document.getElementById("alertBanner");
    document.getElementById("abTitle").textContent=`${pred.confidence}% CONFIDENCE — ${pred.result.toUpperCase()}`;
    document.getElementById("abSub").textContent=`${pred.models.filter(m=>m.weight>.2&&m.detail).map(m=>m.name).join(" · ")}`;
    banner.classList.add("show");
    document.getElementById("abJoin").onclick=()=>chrome.tabs.create({url:"https://bloxyspin.org/coinflip"});
    setTimeout(()=>banner.classList.remove("show"),6000);
  }
  if(cfg.notificationsEnabled) chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"icons/icon48.png",title:`⚡ ${pred.confidence}% Signal — ${pred.result.toUpperCase()}`,message:`High confidence flip detected.`});

  // Auto Join
  if(cfg.autoJoin && pred.confidence >= (cfg.autoJoinThreshold||75)){
    triggerAutoJoin(pred.result, pred.confidence);
  }
}

function renderRecommended(){
  const list=document.getElementById("recList");if(!list)return;
  const threshold=cfg.recThreshold||75;
  const visible=recommendedFlips.filter(r=>r.confidence>=threshold);
  if(!visible.length){list.innerHTML=`<div class="rec-empty">No recommended flips yet.<br>Waiting for ${threshold}%+ confidence signals…<br><br>Open bloxyspin.org/coinflip to start.</div>`;return;}
  list.innerHTML="";
  visible.slice(0,10).forEach(rec=>{
    const card=document.createElement("div");card.className=`rec-card ${rec.result}${rec.confidence>=80?" urgent":""}`;
    const age=Math.floor((Date.now()-rec.time)/1000);const ageStr=age<60?age+"s ago":Math.floor(age/60)+"m ago";
    card.innerHTML=`<div class="rc-top"><div class="rc-side ${rec.result}">${rec.result.toUpperCase()}</div><div class="rc-conf ${rec.tierClass}">${rec.confidence}% CONFIDENCE</div></div><div class="rc-signals">${rec.signals.map(s=>`<span class="sig ${s.side}">${s.name}${s.detail?" · "+s.detail:""}</span>`).join("")}</div><div class="rc-actions"><button class="rc-join-btn" onclick="chrome.tabs.create({url:'https://bloxyspin.org/coinflip'})">OPEN COINFLIP →</button><button class="rc-dismiss" onclick="this.closest('.rec-card').remove()">DISMISS</button><span class="rc-time">${ageStr}</span></div>`;
    list.appendChild(card);
  });
}

// ══════════════════════════════════════════════════════
//  AUTO JOIN
// ══════════════════════════════════════════════════════
let lastAutoJoinKey = null;
let lastAutoJoinGiveawayKey = null;
let autoJoinStatus = { active: false, side: null, time: 0 };

function triggerAutoJoin(side, confidence) {
  // Debounce: use flip count in the key so the same confidence on a NEW flip still fires
  const key = side + "-" + confidence + "-" + allFlipsCache.length;
  if (lastAutoJoinKey === key) return;
  lastAutoJoinKey = key;

  const delay = (cfg.autoJoinDelay || 1200);

  // Prefer the active tab in the current window; fall back to any bloxyspin tab
  chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
    const activeMatch = (activeTabs || []).find(t => t.url && t.url.includes("bloxyspin.org"));

    if (activeMatch) {
      scheduleJoin(activeMatch);
    } else {
      chrome.tabs.query({}, (allTabs) => {
        const tabs = (allTabs || []).filter(t => t.url && t.url.includes("bloxyspin.org"));
        if (!tabs.length) {
          showAutoJoinToast("NO BLOXYSPIN TAB FOUND", "warn");
          return;
        }
        scheduleJoin(tabs[0]);
      });
    }
  });

  function scheduleJoin(tab) {
    autoJoinStatus = { active: true, side, time: Date.now() };
    updateAutoJoinUI("pending", side, confidence);

    setTimeout(() => {
      sendJoin(tab, 0);
    }, delay);
  }

  function sendJoin(tab, attempt) {
    chrome.tabs.sendMessage(tab.id, {
      type: "AUTO_JOIN",
      side,
      confidence,
      minJoin: cfg.autoJoinMin || 100000,
      maxJoin: cfg.autoJoinMax || 200000000
    }, (res) => {
      if (chrome.runtime.lastError) {
        if (attempt < 2) {
          // Content script may not be ready yet — inject it and retry once
          chrome.scripting.executeScript(
            { target: { tabId: tab.id }, files: ["content.js"] },
            () => setTimeout(() => sendJoin(tab, attempt + 1), 600)
          );
          return;
        }
        updateAutoJoinUI("error", side, confidence, "Content script not ready");
        return;
      }
      if (res && res.success) {
        updateAutoJoinUI("joined", side, confidence, res.detail || "");
        showAutoJoinToast(`AUTO JOINED ${side.toUpperCase()} · ${confidence}%`, "success");
      } else {
        updateAutoJoinUI("error", side, confidence, res && res.reason ? res.reason : "Button not found");
      }
      autoJoinStatus.active = false;
    });
  }
}

function updateAutoJoinUI(state, side, confidence, detail) {
  const el = document.getElementById("autoJoinStatus");
  if (!el) return;
  const colors = { pending: "var(--x)", joined: "var(--heads)", error: "var(--tails)", warn: "#ffb347" };
  const icons  = { pending: "⏳", joined: "✅", error: "✗", warn: "⚠" };
  const labels = {
    pending: `Joining ${side ? side.toUpperCase() : ""}… (${confidence}%)`,
    joined:  `Joined ${side ? side.toUpperCase() : ""} · ${confidence}%${detail ? " · "+detail : ""}`,
    error:   `Join failed: ${detail || "unknown"}`,
    warn:    detail || "Warning"
  };
  el.style.color = colors[state] || "var(--muted)";
  el.textContent = (icons[state] || "") + " " + (labels[state] || state);
  el.style.display = "block";
  if (state === "joined" || state === "error" || state === "warn") {
    setTimeout(() => { el.style.display = "none"; el.textContent = ""; }, 5000);
  }
}

function showAutoJoinToast(msg, type) {
  // Reuse bloxy-toast style via a quick notification in the popup header area
  updateAutoJoinUI(type === "success" ? "joined" : "warn", null, null, msg);
}

function formatMineCoord(pos) {
  if (pos == null) return "?";
  if (typeof pos === "string" || typeof pos === "number") return String(pos);
  if (Array.isArray(pos) && pos.length >= 2) return `${pos[0]},${pos[1]}`;
  if (typeof pos === "object") {
    if (pos.row !== undefined && pos.col !== undefined) return `${pos.row},${pos.col}`;
    if (pos.x !== undefined && pos.y !== undefined) return `${pos.x},${pos.y}`;
    if (pos.i !== undefined && pos.j !== undefined) return `${pos.i},${pos.j}`;
    return JSON.stringify(pos).slice(0, 24);
  }
  return String(pos);
}

function extractMineCoordinates(mine) {
  if (!mine || typeof mine !== "object") return [];
  const coords = [];
  const keys = Object.keys(mine);
  for (const key of keys) {
    const lower = key.toLowerCase();
    const value = mine[key];
    if (Array.isArray(value)) {
      value.forEach(item => {
        if (item == null) return;
        if (typeof item === "string" || typeof item === "number" || Array.isArray(item) || typeof item === "object") {
          coords.push(formatMineCoord(item));
        }
      });
    }
    if (lower.includes("grid") && Array.isArray(value)) {
      value.forEach((row, ri) => {
        if (!Array.isArray(row)) return;
        row.forEach((cell, ci) => {
          if (cell && (cell.bomb || cell.mine || cell.isBomb || cell.hasBomb)) coords.push(`${ri},${ci}`);
        });
      });
    }
  }
  return [...new Set(coords)].slice(0, 12);
}

function summarizeMineData(mine) {
  if (!mine) return { status: "NO DATA", html: "No PVP mine payload captured yet. Open the PVP Mines page on bloxyspin and let the extension capture the layout." };
  const coords = extractMineCoordinates(mine.mine || mine || {});
  const bombCount = coords.length || (mine.bombCount || mine.mineCount || 0);
  const summary = [];
  if (bombCount > 0) {
    summary.push(`<div>Detected ${bombCount} possible bomb location${bombCount === 1 ? "" : "s"}.</div>`);
    if (coords.length) {
      summary.push(`<div style="margin-top:6px"><strong>Likely bomb positions:</strong> ${coords.join(", ")}</div>`);
    } else {
      summary.push(`<div style="margin-top:6px;color:var(--muted)">Bomb coordinates are not clearly structured in payload.</div>`);
    }
  } else {
    summary.push(`<div style="color:var(--muted)">Mine payload captured but no explicit bomb positions were extractable.</div>`);
  }
  summary.push(`<div style="margin-top:8px;color:var(--text)">Prediction quality depends on the captured PVP Mines payload format.</div>`);
  return { status: bombCount > 0 ? `${bombCount} bombs found` : "MINE DATA DETECTED", html: summary.join("") };
}

function findBattleIdInPayload(payload){
  if(!payload||typeof payload!=='object')return null;
  const keys=["_id","id","uuid","battleId","game","gameId","matchId","code"];
  for(const k of keys){if(payload[k])return String(payload[k]);}
  // sometimes nested under `mine` or `data`
  if(payload.mine && typeof payload.mine==='object') return findBattleIdInPayload(payload.mine);
  if(payload.data && typeof payload.data==='object') return findBattleIdInPayload(payload.data);
  return null;
}

function generateBombPredictions(battleId, mineCount, heatmap) {
  if (!battleId || mineCount < 3 || mineCount > 8) return [];
  
  // Score each cell based on historical frequency
  const scores = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      const key = `${row},${col}`;
      const freq = heatmap && heatmap[key] ? heatmap[key] : 0;
      // Add small hash-based noise for variety even with same heatmap
      let hash = 0;
      for (let i = 0; i < battleId.length; i++) {
        hash = ((hash << 5) - hash) + battleId.charCodeAt(i);
        hash = hash & hash;
      }
      const noise = Math.sin(hash + row * 7 + col * 11) * 0.3;
      const score = freq + noise;
      scores.push({ key, row, col, score, freq });
    }
  }
  
  // Sort by score descending and pick top N
  scores.sort((a, b) => b.score - a.score);
  return scores.slice(0, mineCount).map(s => s.key);
}

function renderMinePredictionSection() {
  const info = document.getElementById("minePredictionInfo");
  const input = document.getElementById("mineBattleId");
  const select = document.getElementById("mineCountSelect");
  if (!info || !input || !select) return;

  const battleId = input.value.trim();
  const mineCount = Number(select.value) || 5;
  
  if (!battleId) {
    info.innerHTML = `<div style="color:var(--muted);text-align:center;padding:20px;font-family:'Share Tech Mono',monospace;font-size:11px;letter-spacing:.1em">Enter a Battle ID to generate predictions.</div>`;
    return;
  }

  // Fetch heatmap from storage (prefer normalized if present)
  chrome.storage.local.get(["mineHeatmap","mineHeatmapNorm"], (r) => {
    const heatmap = r.mineHeatmapNorm || r.mineHeatmap || {};
    const positions = generateBombPredictions(battleId, mineCount, heatmap);
    const bombSet = new Set(positions);
    
    // Calculate cell confidences
    const cellConfidence = {};
    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        const key = `${row},${col}`;
        cellConfidence[key] = heatmap[key] || 0;
      }
    }
    const maxFreq = Math.max(...Object.values(cellConfidence), 1);
    
    // Build grid HTML with confidence coloring
    let gridHTML = '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin:16px 0;padding:16px;background:rgba(110,68,255,0.03);border:1px solid rgba(110,68,255,0.2);border-radius:10px;width:100%;">';
    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        const key = `${row},${col}`;
        const isBomb = bombSet.has(key);
        const freq = cellConfidence[key];
        const conf = Math.round((freq / maxFreq) * 100);
        const bgOpacity = isBomb ? 0.25 : (conf / 100) * 0.1;
        const bgColor = isBomb ? `rgba(255,61,110,${bgOpacity})` : `rgba(232,255,0,${bgOpacity})`;
        const borderColor = isBomb ? 'rgba(255,61,110,0.6)' : (conf > 30 ? 'rgba(232,255,0,0.3)' : 'rgba(232,255,0,0.1)');
        const glowEffect = isBomb ? 'box-shadow:0 0 12px rgba(255,61,110,0.4),inset 0 0 8px rgba(255,61,110,0.1)' : (conf > 50 ? 'box-shadow:0 0 8px rgba(232,255,0,0.2)' : '');
        gridHTML += `<div style="aspect-ratio:1;background:${bgColor};border:2px solid ${borderColor};border-radius:8px;display:flex;align-items:center;justify-content:center;flex-direction:column;font-weight:900;color:${isBomb ? 'var(--tails)' : 'var(--muted)'};font-size:14px;font-family:'Orbitron',monospace;letter-spacing:.05em;transition:all .2s;${glowEffect};cursor:default;position:relative;" class="mine-cell" title="${isBomb ? 'PREDICTED BOMB' : `Freq: ${conf}%`}">${isBomb ? '💣' : row*5+col}<div style="position:absolute;bottom:4px;font-size:9px;color:var(--muted);font-family:'Share Tech Mono',monospace;opacity:.75">${conf > 0 ? conf + '%' : ''}</div></div>`;
      }
    }
    gridHTML += '</div>';
    
    const gameCount = Object.keys(heatmap).length > 0 ? Math.max(...Object.values(heatmap)) : 0;
    const lines = [];
    lines.push(`<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px;"><div><strong style="font-family:'Orbitron',monospace;font-size:13px;letter-spacing:.1em">BATTLE ID</strong><div style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--x);margin-top:4px;word-break:break-all;">${battleId}</div></div><div style="text-align:right;"><strong style="font-family:'Orbitron',monospace;font-size:13px;letter-spacing:.1em">MINES</strong><div style="font-family:'Orbitron',monospace;font-size:18px;font-weight:900;color:var(--tails);margin-top:4px;">${mineCount}</div></div></div>`);
    lines.push(gridHTML);
    lines.push(`<div style="padding:10px;background:rgba(232,255,0,0.03);border:1px solid rgba(232,255,0,0.1);border-radius:6px;font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--muted);letter-spacing:.05em;"><strong style="color:var(--x)">PREDICTED:</strong> ${positions.join(" • ")}</div>`);
    if (gameCount > 0) {
      lines.push(`<div style="margin-top:8px;padding:8px;background:rgba(0,245,160,0.03);border:1px solid rgba(0,245,160,0.1);border-radius:6px;font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--heads);letter-spacing:.05em;">📊 HEATMAP ACTIVE · Analyzed ${Object.keys(heatmap).length} cells from completed games</div>`);
    }
    lines.push(`<style>.mine-cell:hover{transform:scale(1.05);}</style>`);

    info.innerHTML = lines.join("");
  });
}

function renderMineSection() {
  const label = document.getElementById("mineLabel");
  const info = document.getElementById("mineInfo");
  if (!label || !info) return;
  const mine = mineEvents[0] || null;
  const summary = summarizeMineData(mine);
  label.textContent = summary.status;

  let extra = "";
  if (mineEvents.length > 0) {
    const lastMine = mineEvents[0];
    const lastId = findBattleIdInPayload(lastMine.mine || lastMine) || lastMine.mine?._id || lastMine._id || "unknown";
    extra = `<div style="margin-top:10px;font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--x);line-height:1.4;">Captured ${mineEvents.length} completed game${mineEvents.length === 1 ? "" : "s"}. Latest stored ID: <strong style="color:var(--text)">${lastId}</strong></div>`;
  } else {
    extra = `<div style="margin-top:10px;font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--muted);line-height:1.4;">No completed mine games stored yet. Open Bloxyspin and finish a round to capture data.</div>`;
  }

  info.innerHTML = summary.html + extra;
}

function loadMineData() {
  chrome.runtime.sendMessage({ type: "GET_MINE_DATA" }, (res) => {
    if (!res) return;
    mineEvents = res.mineData || [];
    renderMineSection();
    renderMinePredictionSection();
    // also update heatmap count and recent captures
    chrome.storage.local.get(["mineHeatmap","mineHeatmapNorm"], (r) => {
      const counts = r.mineHeatmap || null;
      const norm = r.mineHeatmapNorm || null;
      const heatmap = counts || norm || {};
      const heatmapCountEl = document.getElementById("heatmapCount");
      if(heatmapCountEl){
        if(counts){
          const sum = Object.values(counts).reduce((a,b)=>a+(typeof b==='number'?b:0),0);
          heatmapCountEl.textContent = String(sum || Object.keys(counts).length);
        } else {
          heatmapCountEl.textContent = String(Object.keys(norm||{}).length);
        }
      }
      const recentEl = document.getElementById("recentMines");
      if(recentEl){
        if(!mineEvents.length){recentEl.textContent = "No captures yet.";}
        else{
          recentEl.innerHTML = "";
          mineEvents.slice(0,12).forEach(m => {
            const id = findBattleIdInPayload(m.mine||m) || m._id || m.id || "unknown";
            const bombs = (m.bombs && m.bombs.length)?m.bombs.join(" "):(m.bombCount||m.mine?.bombCount||0);
            const t = m.timestamp?new Date(m.timestamp).toLocaleString():"";
            const row = document.createElement("div");
            row.style.padding="6px 4px";row.style.borderBottom="1px dashed rgba(255,255,255,0.02)";row.style.fontFamily="Share Tech Mono,monospace";row.style.fontSize="11px";row.style.color="var(--muted)";
            row.innerHTML = `<div style=\"font-weight:700;color:var(--text);font-size:11px;\">${id}</div><div style=\"font-size:11px;color:var(--muted);margin-top:4px;\">Bombs: ${bombs} · ${t}</div>`;
            recentEl.appendChild(row);
          });
        }
      }
    });
  });
}

function normalizeHeatmap(heatmap, alpha=1){
  if(!heatmap||typeof heatmap!=='object')return {};
  const keys = Object.keys(heatmap);
  const smoothed = {};
  let total = 0;
  keys.forEach(k=>{const v = (Number(heatmap[k])||0) + alpha; smoothed[k]=v; total+=v;});
  if(total<=0) return {};
  const prob = {};
  let max = 0;
  keys.forEach(k=>{prob[k]=smoothed[k]/total; if(prob[k]>max) max=prob[k];});
  if(max>0){keys.forEach(k=>{prob[k]=prob[k]/max;});}
  return prob;
}

// ══════════════════════════════════════════════════════
//  AI ANALYSIS
// ══════════════════════════════════════════════════════
let aiAnalysisCache=null,aiAnalysisFlipCount=0;
async function runAIAnalysis(flips){
  const btn=document.getElementById("btnAIAnalyze"),out=document.getElementById("aiOutput");if(!btn||!out)return;
  if(flips.length<10){out.innerHTML=`<div class="ai-msg ai-warn">⚠ Need at least 10 flips. Currently have ${flips.length}.</div>`;return;}
  btn.disabled=true;btn.textContent="ANALYZING…";out.innerHTML=`<div class="ai-msg ai-thinking"><span class="ai-dot">▋</span> Querying AI engine…</div>`;
  const r=flips.slice(-50),seq=r.map(f=>f.result==="heads"?"H":"T").join(" ");
  const h=r.filter(f=>f.result==="heads").length,streak=getStreak(flips),ar=altRate(r);
  const prompt=`You are analyzing coinflip data from a gambling site. Provide a concise, expert analysis of the patterns below.\n\nData (last ${r.length} flips):\nSequence: ${seq}\nHeads: ${h} (${Math.round(h/r.length*100)}%)\nTails: ${r.length-h} (${Math.round((r.length-h)/r.length*100)}%)\nCurrent streak: ${streak.count}× ${streak.side}\nLongest heads streak: ${longestStreak(r,"heads")}\nLongest tails streak: ${longestStreak(r,"tails")}\nAlternation rate: ${Math.round(ar*100)}% (50% = perfectly random)\n\nAnalyze in 3-4 short paragraphs:\n1. Overall bias and distribution\n2. Streak and momentum patterns\n3. Alternation and sequence structure\n4. Your prediction confidence for the next flip and why\n\nBe direct, data-driven, and specific. No disclaimers about randomness needed.`;
  try{
    const result=await new Promise((resolve,reject)=>{
      chrome.runtime.sendMessage({type:"AI_ANALYZE",prompt},res=>{
        if(chrome.runtime.lastError)return reject(new Error(chrome.runtime.lastError.message));
        if(res?.error)return reject(new Error(res.error));
        resolve(res?.text||"");
      });
    });
    const text=result||"No response received.";
    aiAnalysisCache=text;aiAnalysisFlipCount=flips.length;
    out.innerHTML="";
    text.split("\n\n").filter(p=>p.trim()).forEach(para=>{const p=document.createElement("p");p.className="ai-para";p.textContent=para.trim();out.appendChild(p);});
  }catch(e){out.innerHTML=`<div class="ai-msg ai-warn">⚠ AI analysis failed: ${e.message}</div>`;}
  btn.disabled=false;btn.textContent="↻ REFRESH ANALYSIS";
}

// ══════════════════════════════════════════════════════
//  RENDER
// ══════════════════════════════════════════════════════
let lastFlipCount=-1, allFlipsCache=[], prevFlipCount=0;

function render(flips,apiStatus,apiLastPoll){
  allFlipsCache=flips;
  const total=flips.length;
  const isNewFlip = total > prevFlipCount && prevFlipCount >= 0;
  if(isNewFlip && soundEnabled) playFlipTick();
  prevFlipCount=total;

  const heads=flips.filter(f=>f.result==="heads").length;
  const tails=total-heads;
  const hp=total>0?Math.round(heads/total*100):50;

  // Status
  const dot=document.getElementById("feedDot"),info=document.getElementById("feedInfo");
  const badge=document.getElementById("liveBadge"),ldot=document.getElementById("liveDot"),ltext=document.getElementById("liveText");
  if(apiStatus==="ok"){
    dot.className="feed-indicator live";badge.className="live-badge active";ldot.style.background="var(--heads)";
    ltext.textContent="LIVE";info.innerHTML=`<span class="live-t">LIVE · ${timeSince(apiLastPoll)}</span>`;
  } else if(apiStatus==="waiting"||apiStatus==="error"){
    dot.className="feed-indicator";badge.className="live-badge";ltext.textContent="WAITING";
    info.innerHTML=`<span style="color:var(--muted);font-size:9px">OPEN BLOXYSPIN.ORG TO START</span>`;
  } else {
    dot.className="feed-indicator";badge.className="live-badge";ltext.textContent="…";info.textContent="CONNECTING…";
  }

  document.getElementById("statH").textContent=heads;
  document.getElementById("statT").textContent=tails;
  document.getElementById("statN").textContent=total;
  document.getElementById("hPct").textContent=hp+"%";
  document.getElementById("tPct").textContent=(100-hp)+"%";
  document.getElementById("winBar").style.width=hp+"%";

  // Prediction
  const pred=computePrediction(flips,cfg);
  const {count,side}=getStreak(flips);
  lastPredConfidence=pred.confidence;
  lastPrediction=pred;

  // Auto-bet logger
  // Only log if the PREVIOUS prediction had >= 70% confidence
  // pendingPrediction is set AFTER a flip lands, using the prediction from BEFORE that flip
  if(cfg.autoBetLogger&&total>lastFlipCountForAuto&&total>0&&pendingPrediction){
    const newFlip=flips[flips.length-1];
    if(pendingPrediction.result && pendingPrediction.confidence>=70){
      autoLogBet(pendingPrediction.result,newFlip.result,pendingPrediction.confidence,pendingPrediction.pred);
    }
  }
  // Store current prediction as pending — this will be evaluated when the NEXT flip arrives
  if(total!==lastFlipCountForAuto&&pred.result){
    pendingPrediction={result:pred.result,confidence:pred.confidence,pred,flipCount:total};
  } else if(total!==lastFlipCountForAuto&&!pred.result){
    pendingPrediction=null; // not enough data / confidence, don't log
  }
  lastFlipCountForAuto=total;

  // Confidence delta
  if(total!==lastFlipCount){
    confidenceDelta=pred.confidence-prevConfidence;
    prevConfidence=pred.confidence;
    confHistory.push(pred.confidence);
    if(confHistory.length>20) confHistory.shift();
  }

  // Animate gauge
  animateGauge(pred.confidence);
  updateSparkline();

  const coin=document.getElementById("predCoin"),word=document.getElementById("predWord");
  const conf=document.getElementById("predConf"),fill=document.getElementById("confFill");
  const sigs=document.getElementById("signals");
  const deltaEl=document.getElementById("confDelta");
  const agreementEl=document.getElementById("modelAgreement");
  const conflictEl=document.getElementById("conflictWarning");
  const fingerprintEl=document.getElementById("fingerprintRow");

  if(pred.result){
    const c=pred.confidence;
    let tierLabel,tierClass,tierIcon;
    if(c>=80){tierLabel="STRONG SIGNAL";tierClass="tier-strong";tierIcon="🔥";}
    else if(c>=70){tierLabel="GOOD SIGNAL";tierClass="tier-good";tierIcon="✅";}
    else if(c>=63){tierLabel="MODERATE SIGNAL";tierClass="tier-moderate";tierIcon="⚡";}
    else if(c>=57){tierLabel="WEAK SIGNAL";tierClass="tier-weak";tierIcon="⚠️";}
    else{tierLabel="NEAR 50/50 — SKIP";tierClass="tier-skip";tierIcon="❌";}

    coin.className="big-coin "+pred.result+(c>=75?" coin-glow":"");
    coin.textContent=pred.result==="heads"?"H":"T";
    word.className="pred-word "+pred.result;
    word.textContent=pred.result.toUpperCase();
    conf.innerHTML=`<span class="conf-pct ${pred.result}">${c}%</span> · <span class="${tierClass}">${tierIcon} ${tierLabel}</span>`;
    fill.className="conf-fill "+pred.result;
    fill.style.width=Math.min(((c-50)/35*100),100)+"%";

    // Delta indicator
    if(deltaEl&&total!==lastFlipCount){
      const d=confidenceDelta;
      if(Math.abs(d)>=1){
        deltaEl.textContent=(d>0?"↑+":"")+Math.round(d)+"%";
        deltaEl.className="conf-delta "+(d>0?"up":"down");
      } else {deltaEl.textContent="";deltaEl.className="conf-delta";}
    }

    // Model agreement dots
    if(agreementEl){
      const dots=[];
      for(let i=0;i<pred.active;i++) dots.push(`<span class="agree-dot ${i<pred.agreeing?"filled":""}" title="${i<pred.agreeing?"agrees":"disagrees"}"></span>`);
      agreementEl.innerHTML=`<span class="agree-label">${pred.agreeing}/${pred.active} agree</span>${dots.join("")}`;
    }

    // Conflict warning
    if(conflictEl) conflictEl.style.display=pred.conflict?"flex":"none";

    // Pattern fingerprint
    const fp=getFingerprint(flips,5);
    if(fingerprintEl&&fp){
      fingerprintEl.innerHTML=`<span class="fp-label">LAST 5:</span><span class="fp-seq">${fp.pattern}</span><span class="fp-arrow">→</span><span class="fp-next ${fp.predicted==="heads"?"h":"t"}">${fp.hPct}% H</span><span class="fp-count">(n=${fp.total})</span>`;
      fingerprintEl.style.display="flex";
    } else if(fingerprintEl) fingerprintEl.style.display="none";

    // Signals
    if(cfg.showChips){
      sigs.innerHTML="";
      const tierChip=document.createElement("div");tierChip.className=`sig ${tierClass}`;tierChip.textContent=`${tierIcon} ${tierLabel}`;sigs.appendChild(tierChip);
      if(pred.conflict){const ch=document.createElement("div");ch.className="sig tier-skip";ch.textContent="⚠ MODELS DISAGREE — reduced confidence";sigs.appendChild(ch);}
      pred.models.filter(m=>m.weight>.2&&m.detail).forEach(m=>{const ch=document.createElement("div");ch.className="sig "+(m.vote>=.5?"h":"t");const accD=modelAccuracy[m.name];const accStr=accD&&accD.total>=10?` [${Math.round(accD.correct/accD.total*100)}%acc]`:"";ch.textContent=m.name+(m.detail?" · "+m.detail:"")+accStr;sigs.appendChild(ch);});
      if(count>=4){const a=document.createElement("div");a.className="sig streak-alert";a.textContent=`🔥 ${count}× ${side.toUpperCase()} STREAK — watch for reversal`;sigs.appendChild(a);}
      if(total>=10){const r10=flips.slice(-10),rh=r10.filter(f=>f.result==="heads").length;if(rh>=8){const ch=document.createElement("div");ch.className="sig h";ch.textContent=`📈 HEADS HOT — ${rh}/10 recent`;sigs.appendChild(ch);}else if(rh<=2){const ch=document.createElement("div");ch.className="sig t";ch.textContent=`📈 TAILS HOT — ${10-rh}/10 recent`;sigs.appendChild(ch);}}
      if(c<57){const s=document.createElement("div");s.className="sig tier-skip";s.textContent="💡 SKIP — too close to 50/50";sigs.appendChild(s);}
    } else sigs.innerHTML="";

    checkAndAddRecommended(pred,flips);
  } else {
    coin.className="big-coin idle";coin.textContent="?";
    word.className="pred-word idle";word.textContent="WAITING";
    conf.textContent=total>0?`${total} flip${total===1?"":"s"} — need 5+`:"Collecting flips…";
    fill.className="conf-fill idle";fill.style.width="0%";
    sigs.innerHTML="";
    if(deltaEl){deltaEl.textContent="";deltaEl.className="conf-delta";}
    if(agreementEl)agreementEl.innerHTML="";
    if(conflictEl)conflictEl.style.display="none";
    if(fingerprintEl)fingerprintEl.style.display="none";
    animateGauge(50);
  }

  checkCooldown(pred.confidence);

  // Streak
  const sd=document.getElementById("streakDisplay");
  if(count>1&&side){sd.innerHTML=`<span class="sk-num">${count}</span><span class="sk-side ${side}">${side.toUpperCase()}</span>`;}
  else sd.innerHTML=`<span class="sk-none">—</span>`;

  // Flip dots with highlighting
  const dotsEl=document.getElementById("flipDots");
  const readEl=document.getElementById("flipRead");
  if(dotsEl){
    dotsEl.innerHTML="";
    const last20=flips.slice(-20);
    if(!last20.length){
      dotsEl.innerHTML=`<span style="font-family:'Share Tech Mono',monospace;font-size:8px;color:var(--muted)">No flips yet</span>`;
      if(readEl)readEl.innerHTML="";
    } else {
      let streakLen=1;
      const lastSide=last20[last20.length-1].result;
      for(let i=last20.length-2;i>=0;i--){if(last20[i].result===lastSide)streakLen++;else break;}
      let altLen=1;
      for(let i=last20.length-1;i>=1;i--){if(last20[i].result!==last20[i-1].result)altLen++;else break;}
      const isAlternating=altLen>=4;
      const predSide=pred.result;
      const isHighConf=pred.confidence>=63;

      last20.forEach((f,i)=>{
        const d=document.createElement("div");
        const isLast=i===last20.length-1;
        const inStreak=i>=last20.length-streakLen;
        const inAlt=isAlternating&&i>=last20.length-altLen;
        let cls=`fdot ${f.result==="heads"?"h":"t"}`;
        if(isLast)cls+=" new";
        if(inStreak&&streakLen>=3)cls+=" streak-glow";
        if(inAlt&&!inStreak)cls+=" alt-glow";
        d.className=cls;
        d.textContent=f.result==="heads"?"H":"T";
        d.title=cfg.showTimestamps?new Date(f.timestamp).toLocaleTimeString():f.result;
        dotsEl.appendChild(d);
      });

      // Auto-scroll to show newest flip (right end)
      requestAnimationFrame(()=>{ dotsEl.scrollLeft=dotsEl.scrollWidth; });

      if(predSide&&isHighConf){
        const sep=document.createElement("div");sep.className="fdot-sep";sep.textContent="→";dotsEl.appendChild(sep);
        const ghost=document.createElement("div");
        ghost.className=`fdot fdot-pred ${predSide==="heads"?"h":"t"} ${pred.confidence>=75?"fdot-pred-strong":"fdot-pred-weak"}`;
        ghost.textContent=predSide==="heads"?"H":"T";
        ghost.title=`Predicted: ${predSide} (${pred.confidence}%)`;
        dotsEl.appendChild(ghost);
      }

      if(readEl){
        const parts=[];
        if(streakLen>=3){
          parts.push(`<span class="pr-streak ${lastSide==="heads"?"h":"t"}">${streakLen}× ${lastSide.toUpperCase()} streak</span>`);
          if(streakLen>=4&&predSide&&predSide!==lastSide&&isHighConf)parts.push(`<span class="pr-signal t">→ reversal signal</span>`);
          else if(streakLen>=3&&predSide===lastSide&&isHighConf)parts.push(`<span class="pr-signal h">→ momentum continuing</span>`);
        }
        if(isAlternating){parts.push(`<span class="pr-alt">↔ alternating (${altLen}×)</span>`);if(predSide&&isHighConf)parts.push(`<span class="pr-signal ${predSide==="heads"?"h":"t"}">→ next: ${predSide.toUpperCase()}</span>`);}
        const r10=last20.slice(-10),r10h=r10.filter(x=>x.result==="heads").length;
        if(r10h>=7&&!isAlternating)parts.push(`<span class="pr-bias h">📈 heads bias ${r10h}/10</span>`);
        else if(r10h<=3&&!isAlternating)parts.push(`<span class="pr-bias t">📈 tails bias ${10-r10h}/10</span>`);
        if(predSide&&pred.confidence>=75&&parts.length===0)parts.push(`<span class="pr-signal ${predSide==="heads"?"h":"t"}">⚡ ${pred.confidence}% → ${predSide.toUpperCase()} looks winnable</span>`);
        else if(!predSide||pred.confidence<57)parts.push(`<span class="pr-neutral">near 50/50 — skip</span>`);
        readEl.innerHTML=parts.length?parts.join("<span class='pr-dot'>·</span>"):"";
      }
    }
  }

  // Hot/Cold/Last10
  const lh=longestStreak(flips,"heads"),lt=longestStreak(flips,"tails");
  const hotEl=document.getElementById("hotStreak"),coldEl=document.getElementById("coldStreak"),l10El=document.getElementById("last10"),l10SubEl=document.getElementById("last10Sub");
  if(hotEl){hotEl.textContent=total?lh+"x":"—";coldEl.textContent=total?lt+"x":"—";}
  if(l10El&&total>0){const l10=flips.slice(-10),l10h=l10.filter(f=>f.result==="heads").length;l10El.textContent=`${l10h}H`;l10SubEl.textContent=`${l10.length-l10h}T in ${l10.length}`;l10El.className=l10h>l10.length-l10h?"hc-val h":l10h<l10.length-l10h?"hc-val t":"hc-val x";}
  else if(l10El){l10El.textContent="—";l10SubEl.textContent="H vs T";}

  // Momentum
  const momH=document.getElementById("momFillH"),momT=document.getElementById("momFillT"),momLbl=document.getElementById("momLabel");
  if(momH&&total>=3){
    const rec=flips.slice(-20);let hScore=0,tScore=0;
    rec.forEach((f,i)=>{const w=(i+1)/rec.length;f.result==="heads"?hScore+=w:tScore+=w;});
    const tw=hScore+tScore,hMom=tw>0?hScore/tw:.5;
    momH.style.width=(hMom*100).toFixed(1)+"%";momT.style.width=((1-hMom)*100).toFixed(1)+"%";
    const diff=Math.abs(hMom-.5);
    if(diff<.08){momLbl.textContent="NEUTRAL";momLbl.style.color="var(--x)";}
    else if(hMom>.5){momLbl.textContent="HEADS DOMINANT";momLbl.style.color="var(--heads)";}
    else{momLbl.textContent="TAILS DOMINANT";momLbl.style.color="var(--tails)";}
  }

  // History grid
  const grid=document.getElementById("histGrid");
  document.getElementById("histMeta").textContent=`${total} FLIPS`;
  if(!flips.length){grid.innerHTML='<div class="hist-empty">No flips recorded yet.</div>';}
  else{grid.innerHTML="";[...flips].reverse().slice(0,80).forEach((f,i)=>{const d=document.createElement("span");d.className=`hdot ${f.result}${f.source==="api"?" api":""}`;d.textContent=f.result==="heads"?"H":"T";d.title=(f.source==="api"?"🌐 ":"✋ ")+new Date(f.timestamp).toLocaleTimeString();d.style.animationDelay=(i*.01)+"s";grid.appendChild(d);});}

  // Pattern stats
  if(total>0){
    document.getElementById("patH").textContent=hp+"%";document.getElementById("patHBar").style.width=hp+"%";
    document.getElementById("patT").textContent=(100-hp)+"%";document.getElementById("patTBar").style.width=(100-hp)+"%";
    const maxSk=Math.max(lh,lt,1);
    document.getElementById("patLH").textContent=lh;document.getElementById("patLHBar").style.width=(lh/maxSk*100)+"%";
    document.getElementById("patLT").textContent=lt;document.getElementById("patLTBar").style.width=(lt/maxSk*100)+"%";
    const ar=altRate(flips);
    document.getElementById("patAlt").textContent=Math.round(ar*100)+"%";document.getElementById("patAltBar").style.width=(ar*100)+"%";
    const avg=avgRunLen(flips);
    document.getElementById("patRun").textContent=avg.toFixed(2);document.getElementById("patRunBar").style.width=Math.min(avg/5*100,100)+"%";
  }

  // Analytics models
  const ml=document.getElementById("modelList");
  if(pred.result&&pred.models.length){
    ml.innerHTML="";
    pred.models.forEach(m=>{
      const s=m.weight>0?(m.vote>=.5?"h":"t"):"n",pct=m.weight>0?Math.round(m.vote*100):50,w=Math.round(m.weight*100);
      const accData=modelAccuracy[m.name];
      const accStr=accData&&accData.total>=5?` · ${Math.round(accData.correct/accData.total*100)}% acc (${accData.total})`:"";
      const row=document.createElement("div");row.className="model-row";
      row.innerHTML=`<div class="model-top"><span class="model-name">${m.name}</span><span class="model-vote ${s}">${m.weight>0?pct+"% H":"INACTIVE"}</span></div><div class="model-bar-wrap"><div class="model-bar ${s}" style="width:${m.weight>0?pct:50}%"></div></div><div class="model-weight">${m.detail||"—"} · weight ${w}${accStr}</div>`;
      ml.appendChild(row);
    });
  } else ml.innerHTML=`<div style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--muted);padding:8px 0">Log 5+ flips to activate models.</div>`;

  // Distribution chart
  const distBars=document.getElementById("distBars");distBars.innerHTML="";
  const last50=flips.slice(-50);
  if(last50.length){const blockSize=5,blocks=[];for(let i=0;i<last50.length;i+=blockSize){const chunk=last50.slice(i,i+blockSize),h=chunk.filter(f=>f.result==="heads").length;blocks.push({h,t:chunk.length-h,side:h>=chunk.length/2?"h":"t"});}blocks.forEach(b=>{const bar=document.createElement("div");bar.className=`dist-bar ${b.side}`;bar.style.height=(b.h/blockSize*100)+"%";bar.title=`H:${b.h} T:${b.t}`;distBars.appendChild(bar);});}

  // Confidence history chart
  const confEl=document.getElementById("confHistory");
  if(confEl&&confHistory.length){confEl.innerHTML="";const maxC=Math.max(...confHistory,60);confHistory.forEach(c=>{const bar=document.createElement("div");bar.className=`dist-bar ${c>=75?"h":c>=63?"":"t"}`;bar.style.height=((c-50)/(maxC-50)*100)+"%";bar.style.minHeight="4px";bar.title=`${c}% confidence`;confEl.appendChild(bar);});}

  lastFlipCount=total;
}

// ══════════════════════════════════════════════════════
//  TABS
// ══════════════════════════════════════════════════════
document.querySelectorAll(".tab").forEach(tab=>{
  tab.addEventListener("click",()=>{
    document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
    document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("page-"+tab.dataset.tab).classList.add("active");
    if(tab.dataset.tab==="alerts"){alertCount=0;const b=document.getElementById("alertBadge");if(b)b.style.display="none";renderRecommended();}
    if(tab.dataset.tab==="accuracy")renderAccuracy();
  });
});

// ══════════════════════════════════════════════════════
//  SETTINGS UI
// ══════════════════════════════════════════════════════
function applySettingsUI(){
  document.querySelectorAll(".toggle").forEach(el=>{
    const key=el.dataset.key;
    if(key&&cfg[key]!==undefined){
      el.className="toggle "+(cfg[key]?"on":"");
      el.onclick=()=>{cfg[key]=!cfg[key];el.className="toggle "+(cfg[key]?"on":"");saveSettings();
        if(key==="autoBetLogger"){const info=document.getElementById("autoBetInfo");if(info)info.textContent=cfg[key]?"Auto-logging 70%+ predictions":"Manual only";}
      };
    }
  });
  const mf=document.getElementById("maxFlips");if(mf){mf.value=String(cfg.maxFlips||500);mf.onchange=()=>{cfg.maxFlips=Number(mf.value);saveSettings();};}
  const rt=document.getElementById("recThreshold");if(rt){rt.value=String(cfg.recThreshold||75);rt.onchange=()=>{cfg.recThreshold=Number(rt.value);saveSettings();renderRecommended();};}
  const stb=document.getElementById("soundToggle");soundEnabled=cfg.soundAlerts||false;
  if(stb){stb.textContent=soundEnabled?"ON":"OFF";stb.className="sound-btn "+(soundEnabled?"active":"");stb.onclick=()=>{soundEnabled=!soundEnabled;cfg.soundAlerts=soundEnabled;saveSettings();stb.textContent=soundEnabled?"ON":"OFF";stb.className="sound-btn "+(soundEnabled?"active":"");};}
  const ajt=document.getElementById("autoJoinThreshold");if(ajt){ajt.value=String(cfg.autoJoinThreshold||75);ajt.onchange=()=>{cfg.autoJoinThreshold=Number(ajt.value);saveSettings();};}
  const ajd=document.getElementById("autoJoinDelay");if(ajd){ajd.value=String(cfg.autoJoinDelay||1200);ajd.onchange=()=>{cfg.autoJoinDelay=Number(ajd.value);saveSettings();};}
  const ajMin=document.getElementById("autoJoinMin");if(ajMin){ajMin.value=String(cfg.autoJoinMin||100000);ajMin.onchange=()=>{let v=Math.max(1,Number(ajMin.value)||1);cfg.autoJoinMin=v;if((cfg.autoJoinMax||200000000)<v){cfg.autoJoinMax=v;const mx=document.getElementById("autoJoinMax");if(mx)mx.value=String(v);}saveSettings();};}
  const ajMax=document.getElementById("autoJoinMax");if(ajMax){ajMax.value=String(cfg.autoJoinMax||200000000);ajMax.onchange=()=>{let v=Math.max(cfg.autoJoinMin||100000,Number(ajMax.value)||1);cfg.autoJoinMax=v;saveSettings();ajMax.value=String(v);};}
  const ajg=document.getElementById("autoJoinGiveaway");if(ajg){ajg.className="toggle "+(cfg.autoJoinGiveaway?"on":"");ajg.onclick=()=>{cfg.autoJoinGiveaway=!cfg.autoJoinGiveaway;ajg.className="toggle "+(cfg.autoJoinGiveaway?"on":"");lastAutoJoinGiveawayKey=null;saveSettings();};}
  const ajgd=document.getElementById("autoJoinGiveawayDelay");if(ajgd){ajgd.value=String(cfg.autoJoinGiveawayDelay||800);ajgd.onchange=()=>{cfg.autoJoinGiveawayDelay=Number(ajgd.value);saveSettings();};}
}

// ══════════════════════════════════════════════════════
//  EVENTS
// ══════════════════════════════════════════════════════
function loadData(){
  chrome.runtime.sendMessage({type:"GET_FLIPS"},res=>{
    if(res){render(res.flips||[],res.apiStatus,res.apiLastPoll);
      const el=document.getElementById("apiDebug");
      if(el){if(res.apiError)el.innerHTML=`<span style="color:var(--tails)">ERROR: ${res.apiError}</span>`;else el.textContent=res.apiRaw?"RAW: "+res.apiRaw.slice(0,200):"Waiting…";}
    }
  });
  loadMineData();
}
function addFlip(result){
  chrome.runtime.sendMessage({type:"ADD_FLIP",result},res=>{
    if(res?.flips)render(res.flips,null,null);
    const btn=result==="heads"?document.getElementById("btnH"):document.getElementById("btnT");
    btn.classList.add("pulse");setTimeout(()=>btn.classList.remove("pulse"),350);
  });
}
document.getElementById("btnH").addEventListener("click",()=>addFlip("heads"));
document.getElementById("btnT").addEventListener("click",()=>addFlip("tails"));
document.getElementById("btnSync").addEventListener("click",()=>{const b=document.getElementById("btnSync");b.classList.add("spin");setTimeout(()=>b.classList.remove("spin"),400);chrome.runtime.sendMessage({type:"FORCE_POLL"});setTimeout(loadData,1000);});
document.getElementById("btnClear").addEventListener("click",()=>{if(confirm("Clear ALL flip history?"))chrome.runtime.sendMessage({type:"CLEAR_FLIPS"},()=>render([],null,null));});
document.getElementById("btnReset").addEventListener("click",()=>{if(confirm("Reset all settings to defaults?")){cfg={...DEFAULT_CFG};saveSettings();applySettingsUI();}});
document.getElementById("abClose").addEventListener("click",()=>document.getElementById("alertBanner").classList.remove("show"));

document.getElementById("btnSaveApiKey").addEventListener("click",()=>{
  const val=document.getElementById("apiKeyInput").value.trim(),status=document.getElementById("apiKeyStatus");
  if(!val){status.style.color="var(--tails)";status.textContent="Please enter a key.";return;}
  if(!val.startsWith("sk-")){status.style.color="var(--tails)";status.textContent="Key should start with sk-ant-...";return;}
  chrome.runtime.sendMessage({type:"SAVE_API_KEY",key:val},()=>{status.style.color="var(--heads)";status.textContent="✓ Key saved";document.getElementById("apiKeyInput").value="";setTimeout(()=>{status.textContent="Key stored securely";status.style.color="var(--muted)";},2500);});
});
chrome.storage.local.get(["xpAnthropicKey"],r=>{const status=document.getElementById("apiKeyStatus");if(status){if(r.xpAnthropicKey){status.style.color="var(--heads)";status.textContent="✓ Key saved — AI Analysis ready";}else{status.style.color="var(--muted)";status.textContent="No key saved yet";}}});

document.getElementById("btnExportCSV").addEventListener("click",()=>{if(!allFlipsCache.length){alert("No flips to export.");return;}exportCSV(allFlipsCache);});
document.getElementById("btnClearAccuracy")&&document.getElementById("btnClearAccuracy").addEventListener("click",()=>{if(confirm("Clear all accuracy data?")){betLog=[];totalCorrect=0;totalBets=0;currentBestWin=0;currentWorstLoss=0;currentWinStreak=0;currentLossStreak=0;modelAccuracy={};calibrationData=[];saveBetLog();saveModelAccuracy();saveCalibration();renderAccuracy();}});
document.getElementById("btnSaveSession")&&document.getElementById("btnSaveSession").addEventListener("click",()=>{archiveCurrentSession();renderSessions();const btn=document.getElementById("btnSaveSession");btn.textContent="SAVED ✓";setTimeout(()=>btn.textContent="SAVE SESSION",2000);});
document.getElementById("btnAIAnalyze")&&document.getElementById("btnAIAnalyze").addEventListener("click",()=>runAIAnalysis(allFlipsCache));
document.getElementById("btnPredictMines")&&document.getElementById("btnPredictMines").addEventListener("click",()=>renderMinePredictionSection());
document.getElementById("mineBattleId")&&document.getElementById("mineBattleId").addEventListener("keydown",(e)=>{if(e.key==="Enter"){e.preventDefault();renderMinePredictionSection();}});
document.getElementById("mineCountSelect")&&document.getElementById("mineCountSelect").addEventListener("change",()=>renderMinePredictionSection());


document.addEventListener("DOMContentLoaded",()=>{renderMinePredictionSection();});

chrome.storage.onChanged.addListener(changes=>{
  if(changes.flips||changes.apiStatus)loadData();
  if(changes.mineData){loadMineData();}
});
setInterval(loadData,4000);
setInterval(renderRecommended,30000);

(async()=>{
  await loadSettings();
  applySettingsUI();
  loadData();
  loadBetLog();
  loadModelAccuracy();
  loadCalibration();
  loadSavedSessions();
  renderAccuracy();
  renderSessions();
  // Init canvas after DOM ready
  setTimeout(()=>{drawGauge(50);},100);
})();

// ══════════════════════════════════════════════════════
//  UPDATE BANNER
// ══════════════════════════════════════════════════════
function renderUpdateBanner(info){
  const banner=document.getElementById("updateBanner");
  if(!banner) return;
  if(!info || !info.available){ banner.classList.remove("show"); return; }
  chrome.storage.local.get(["updateDismissedVersion"],(r)=>{
    if(r.updateDismissedVersion === info.latestVersion){ banner.classList.remove("show"); return; }
    document.getElementById("updSub").textContent = `v${info.latestVersion} · ${info.notes || "New version ready"}`;
    banner.classList.add("show");
  });
}
document.getElementById("updClose").addEventListener("click",()=>{
  chrome.runtime.sendMessage({type:"GET_UPDATE_INFO"},(r)=>{
    const v = r && r.updateInfo ? r.updateInfo.latestVersion : null;
    if(v) chrome.storage.local.set({updateDismissedVersion:v});
  });
  document.getElementById("updateBanner").classList.remove("show");
});
document.getElementById("updGet").addEventListener("click",()=>{
  chrome.runtime.sendMessage({type:"GET_UPDATE_INFO"},(r)=>{
    const url = r && r.updateInfo ? r.updateInfo.downloadUrl : null;
    if(url) chrome.tabs.create({url});
  });
});
chrome.runtime.sendMessage({type:"CHECK_FOR_UPDATE_NOW"},(r)=>{
  renderUpdateBanner(r && r.updateInfo ? r.updateInfo : null);
});
